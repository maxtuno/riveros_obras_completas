# Revisión adversarial del paper (segunda ronda)

**Manuscrito:** `PAPER_SIMETRIA_RANGO_COMPRESION_REVISION_CORREGIDA.tex`
**Fecha:** 30 de octubre de 2026
**Autor:** Oscar Riveros
**Colaboradores:** DeepSeek V4.1 Flash 1017 via Kilo Code; ChatGPT (GPT-6)

## Veredicto de la primera pasada

Revisión mayor. El núcleo matemático resiste, pero había errores lógicos,
condiciones implícitas y una afirmación experimental no respaldada por el
código. Todos los hallazgos siguientes se corrigieron en el manuscrito.

## Hallazgos y correcciones

### Críticos / mayores

| ID | Ubicación | Hallazgo | Corrección |
|---|---|---|---|
| M1 | Sección 3.2 | «Una reducción polinómica de HAMPATH cúbico a GI implicaría P=NP» es falso para GI general: implicaría que GI es NP-completo. Solo una reducción a GI de grado acotado daría P=NP. | Se separaron ambos casos. |
| M2 | Sección 8.1 y discusión | El abstract de OpenAI usa `rho(n)=n(log log n)^2/sqrt(log n)=n/(log n)^{1/2+o(1)}`, que es más débil que el teorema `2^{O(n log log n/sqrt(log n))}`. Un intento intermedio invirtió la dirección. | Se restauró la dirección correcta: el teorema es más fuerte; el abstract y la nota Lean usan `rho(n)`. |
| M3 | Sección 5 | El texto afirmaba que `hampath_cograph.py` validaba la reconstrucción de cada camino; el `main` solo comparaba decisión contra Held–Karp. | Se añadió reconstrucción y validación de aristas en el script. Resultado: 700 cografos, 294 caminos reconstruidos, 0 discrepancias. |
| M4 | Sección 3.2 | La construcción de candidatos cúbicos era vaga («emparejamiento de vértices internos de la misma paridad») y no demostraba que el filtro de grados dejara exponenciales candidatos. | Se reemplazó por la construcción explícita ciclo `C_n` + emparejamiento perfecto que evita sus aristas; al menos `2^{n/6}` objetivos para `n` múltiplo de 6. |
| M5 | Sección 8.2 | «Set Splitting» y «coloración» se presentaban como subexponenciales sin condiciones sobre `M`. Para coloración densa, `M=Theta(n^2)` y la cota no es subexponencial en `N`. | Se añadieron las condiciones `M=O(N)` y `m=O(n)` en texto y tabla. |
| M6 | Sección 7.3 | La proposición de compresión daba tiempo `poly(q, max K_t)` sin incluir el tamaño de la fórmula. | Se añadió `|F|` a la cota y al argumento. |
| M7 | Sección 4.2 | «Un grafo con un único camino tiene rango 1» es falso si se cuentan las dos orientaciones. | Se precisó: rango 1 para un único camino orientado; rango 2 para las dos orientaciones de un camino no orientado. |
| M8 | Introducción | Decía «Tres observaciones» y enumeraba seis; además la descripción de secciones 2–6/7 estaba desactualizada. | Se corrigió a seis observaciones y al mapa real de secciones. |

### Moderados

| ID | Ubicación | Hallazgo | Corrección |
|---|---|---|---|
| m1 | Sección 5 | La distancia entre intervalos usaba `d` como función y como extremo. | Se renombró a `delta` y se escribió `delta([a,b],[c,e]) = max(0,a-e,c-b)`. |
| m2 | Sección 5 | «HAMPATH sigue siendo NP-completo en nodos primos» no estaba justificado. | Se suavizó: no hay DP de intervalos y el método no se extiende automáticamente. |
| m3 | Sección 6.2 | «El perfil se colapsa al intervalo [p,n]» era impreciso: el perfil y el estado de cografos son objetos distintos. | Se cambió a «el estado relevante se colapsa». |
| m4 | Sección 4.1 | La DP de subconjuntos se describía con `C(n,k)` estados en el nivel `k`, omitiendo el extremo. | Se precisó `k·C(n,k)` estados. |
| m5 | Discusión | El ítem de descomposición de cruces usaba `rho` sin definirla. | Se definió como la constante de la recursión de Anthropic. |
| m6 | Discusión | El ítem del abstract de OpenAI afirmaba que «si la cota fuerte se sostiene» bajaría el exponente; la dirección era incorrecta. | Se reemplazó por la discrepancia literal entre abstract y teorema. |
| m7 | Sección 8.1 | «La formalización Lean … no se usa como certificado de P=NP» confundía el alcance. | Se reformuló como certificado de correspondencia con el teorema. |
| m8 | Bibliografía | La fecha del preprint de Anthropic decía 27 de octubre; el PDF dice 26. | Se corrigió a 26 de octubre de 2026. |

### Menores

| ID | Ubicación | Hallazgo | Corrección |
|---|---|---|---|
| n1 | Sección 3.1 | «573 tienen camino hamiltoniano y no son isomorfos a P5» era correcto pero incompleto: hay 633 con camino y 60 etiquetas de P5. | Se explicitó el desglose. |
| n2 | Tabla de filtros | Los grafos aleatorios no indicaban semilla. | Se añadió «semilla 1» en el caption. |
| n3 | Tablas de rango | No indicaban el cuerpo de cálculo. | Se añadió `F_{10^9+7}` en los captions. |
| n4 | Bibliografía | `babai2016` y `valiant1979` no se citaban. | Se citaron en el texto (GI general y #P-completitud). |
| n5 | Cabecera | La nota de contribución no incluía a los dos colaboradores solicitados. | Se añadió la observación con DeepSeek V4.1 Flash 1017 via Kilo Code y ChatGPT (GPT-6). |

## Verificaciones computacionales

- `python hampath_cograph.py`: 700 cografos, 294 caminos reconstruidos y
  validados, 0 discrepancias.
- `python hampath_block_rank.py`: factorización de bloques, rango exacto,
  suma de rangos e identidad de conteo; 64 grafos n=4, 128 n=5 y 32 n=6.
- Conteo de grafos n=5: 633 con camino hamiltoniano; 573 no isomorfos a P5;
  60 etiquetas de P5.
- Tablas de simetría, rango, tensor completo y filtros contrastadas con
  `paper_material/outputs/`.

## Correcciones adicionales de la segunda pasada

- Se reemplazó «el caso cúbico muestra que no puede ser un simple isomorfismo
  del mismo grafo» por la forma condicional correcta: «implicaría \(P=NP\)».
- Se añadió un esbozo de corrección de la codificación por flujo cúbico
  (super-root, flujo decreciente y exclusión de ciclos desconectados).
- Se unificó «intersección» por «conjunción de factores locales» en el resumen,
  en línea con el teorema de composición de firmas.
- Se añadieron las condiciones `M=O(N)` y `m=O(n)` en las filas de la tabla de
  codificaciones.
- Se especificó el cuerpo \(\mathbb{F}_{10^9+7}\) en las tablas de rango.
- Se añadió la suposición de descomposición de árbol niza (hoja, introducción,
  olvido, unión) en el teorema de firmas.
- Se unificó la notación: \(M\) cláusulas (la \(m\) anterior), \(e\) aristas; el
  enunciado de OpenAI se cita con \(M\).
- Se precisó que los demás filtros no se analizan con el mismo detalle.
- Se documentó en el README que `linear_encodings.py` verifica decisión, no
  conteo.

## Equivalencia de la versión inglesa

Se escribió `PAPER_SYMMETRY_RANK_COMPRESSION_EN.tex` como traducción de la
versión corregida. Comprobaciones automáticas:

- 35 secciones/subsecciones, una a una, con el mismo orden.
- 25 etiquetas `\label` idénticas.
- 11 claves de cita idénticas.
- Mismos entornos: 8 teoremas, 2 lemas, 2 proposiciones, 3 corolarios y 1
  observación.
- 7 tablas; la secuencia numérica de cada tabla coincide exactamente.
- 18 páginas en ambos PDF, sin referencias indefinidas ni overfull.
- El contenido matemático de los 16 entornos teoremáticos coincide tras
  eliminar el texto traducido.

La versión inglesa conserva los títulos originales de las obras de Riveros en
la bibliografía, con traducción entre corchetes.

## Estado

Primera pasada corregida y recompilada (18 páginas, sin referencias
indefinidas ni overfull). Versión inglesa compilada y contrastada
estructuralmente.

## Revisión independiente: resultados

### Revisor del manuscrito español

Veredicto inicial: **revisión mayor**. Hallazgos y tratamiento:

- **C1, cota de OpenAI:** era correcto que faltaba `sqrt(log n)`. La dirección
  correcta es que el teorema explícito
  `2^{O(n log log n / sqrt(log n))}` es más fuerte que el abstract, que usa
  `rho(n)=n(log log n)^2/sqrt(log n)=n/(log n)^{1/2+o(1)}`. Un intento
  intermedio invirtió la dirección; la revisión inglesa lo detectó y se
  restauró la forma correcta.
- **C2, flujo cúbico:** el revisor usó una lectura incorrecta del teorema de
  Anthropic (`k sqrt(n log log n / log n)`). La página 2 renderizada de
  `antropic.pdf` da `k^2 n log log n / sqrt(log n)` y `k m / sqrt(log m)`. Con
  `N=M=n log n` y `k=3`,
  `k^2 N log log N / sqrt(log N) = Theta(n sqrt(log n) log log n)` y
  `k M / sqrt(log M) = Theta(n sqrt(log n))`, ambos muy por encima de `n`. Por
  tanto, ambos bounds son peores que `2^n`; la conclusión «no mejora» se
  mantiene. El texto ahora declara `k=3` y muestra los dos bounds.
- **M1/M2, condiciones de ancho:** correcto. Se añadió `k=O(1)` en Set
  Splitting y ancho constante en el problema de `O(n)` cláusulas.
- **m1, GI:** correcto. La discusión ahora distingue GI de grado acotado
  (`P=NP`) de GI general (GI NP-completo).
- **m2, DP comprimida:** correcto. Se añadió la hipótesis (d) sobre la
  construcción de la firma inicial.
- **m3, descomposición de árbol:** correcto. Se cambió a grafo primal.
- **m4, cografos:** correcto. Se precisó «vértice-disjuntos (posiblemente
  triviales)».
- **m5, rango 1:** correcto. Se eliminó el caso imposible y se dejó rango 2
  para un único camino no orientado.
- **m6, filtros:** correcto. Se precisó que el filtro de grados, por sí solo,
  no da una reducción polinómica.
- **Menores:** autor Claude (Anthropic), semillas en README, cuerda `(1,3)`,
  warning hyperref y calificación de `O(n)` variables en el peor caso:
  corregidos.

### Revisor de la versión inglesa

Veredicto inicial: **revisión mayor localizada**. Hallazgos y tratamiento:

- Cota de OpenAI: raíz corregida; dirección final: el abstract usa `rho(n)` y
  es más débil, el teorema es más fuerte.
- Set Splitting: añadida la condición `k=O(1)`.
- Segundo bound del flujo: corregido a
  `2^{O(n sqrt(log n) log log n)}`.
- `L_n`: definido como matrices de adyacencia de grafos simples.
- Rango 1: eliminado; se dejó el caso no orientado con rango 2.
- Colisión `m/M`: unificada a `M` para cláusulas y `e` para aristas.
- Teorema 14: precisado por nodo.
- Reproducibilidad: README con Python 3.15.2, semillas y convenciones.
- Título de la nota Lean: separado en título y descriptor.
- Autores: se mantienen los identificadores solicitados por el autor.

### Re-revisión final

- **Revisor español:** veredicto de revisión menor. N1 (factores locales en la
  firma inicial del Teorema 14) corregido en ambos idiomas. N2 (script
  `eth_improvements.py`) ya estaba corregido en el paquete actual: la línea 53
  usa `sqrt(log n)` y la salida regenerada no tiene la columna antigua.
- **Revisor inglés:** detectó una inversión de la dirección abstract/teorema
  introducida en la corrección anterior. Restaurada: el abstract usa `rho(n)`,
  es más débil; el teorema es más fuerte. También se alinearon la redacción del
  Teorema 14 y el título de la nota Lean en la bibliografía inglesa.
- **Estado:** ambos manuscritos compilan en 18 páginas, sin warnings, con 25
  labels, 11 citas, 16 entornos, 7 tablas y contenido matemático equivalente.

### Confirmación final

- Revisor del manuscrito español: **ACEPTAR**.
- Revisor de la versión inglesa y de la equivalencia: **ACEPTAR**.
- Ciclo de revisión cerrado: no quedan errores reales reportados.

## Revisión independiente (en curso)

Se lanzaron dos revisores adversariales independientes:

- revisor del manuscrito español (`ses_e711ace48ffeCPVC4HqViQZ92w`);
- revisor de la versión inglesa y de su equivalencia con la española
  (`ses_e7114140affep6yJVH2ZK37Zg2`).

Al recibir sus informes se corregirá cualquier hallazgo nuevo en ambos
manuscritos, se recompilará y se repetirá la revisión hasta que no queden
errores reales.
