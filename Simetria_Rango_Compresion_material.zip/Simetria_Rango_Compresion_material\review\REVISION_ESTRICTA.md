# Revisión estricta del manuscrito revisado

**Documento revisado:** `PAPER_SIMETRIA_RANGO_COMPRESION_REVISION.tex`  
**Versión corregida:** `PAPER_SIMETRIA_RANGO_COMPRESION_REVISION_CORREGIDA.tex`  
**Fecha:** 30 de octubre de 2026

## Recomendación

Revisión mayor, no aceptación directa. El manuscrito contiene resultados
correctos y una estructura matemática sólida, pero incluye un error factual en
la cota explícita de OpenAI, una afirmación de reproducibilidad que no
correspondía al material entregado y varias ambigüedades de alcance. Se preparó
una versión corregida; la versión revisada se conserva en `review/`.

## Hallazgos

| ID | Severidad | Ubicación | Hallazgo | Acción |
|---|---|---|---|---|
| M1 | Mayor | Sección 8.1 | La cota general de OpenAI se escribe como `2^{O(n log log n / sqrt(log n))}` y el resumen como `2^{n/(log n)^{1/2+o(1)}}`. El teorema explícito del preprint da `2^{O(n log log n / log n)}`; la cota para `m <= Dn` es `2^{O(n/sqrt(log n))}`. La cota del resumen y la de Lean no coinciden literalmente con el teorema. | Corregido: se cita la cota explícita y se separan resumen/Lean. No se usa la versión más fuerte como establecida. |
| M2 | Mayor | Secciones 9–10 | El texto dice que los scripts no fueron incluidos y que las tablas no están reproducidas. El paquete sí los incluye ahora; la afirmación quedó desactualizada. | Corregido: el paper apunta a `paper_material/`, y el paquete contiene código, instancias y salidas. |
| M3 | Moderada | Sección 7 | El “álgebra de firmas de frontera” se presenta como contribución central, pero es la programación dinámica estándar sobre descomposiciones de árbol. La corrección del join no es nueva; lo específico es el criterio de compresión y la compatibilidad con simetrías. | Corregido: se explicita que el marco recupera la DP estándar y se acota la novedad. |
| m1 | Menor | Sección 7.1 | El join se define para relaciones con variables compartidas `S`, pero no se aclaraba cómo se extienden las relaciones de los hijos a la frontera común. | Corregido: se añade la extensión a la frontera del nodo y la introducción sin cuantificar. |
| m2 | Menor | Tabla de rango completo | La columna “caminos” no distinguía caminos orientados de no orientados. Los valores de la tabla son órdenes de vértices. | Corregido: el caption dice “caminos orientados”. |
| m3 | Menor | Sección 5 | La reconstrucción en cografos se anunciaba como `O(n)`; la decisión es `O(n)`, pero la reconstrucción explícita con listas es `O(n²)`. | Corregido: se separan ambas cotas. |

## Resultados que resistieron la revisión

- **Burnside firmado.** El teorema de puntos fijos y el corolario son correctos;
  la paridad de cada ciclo es la condición necesaria y suficiente.
- **SAT-ORBIT general.** La NP-completitud con `G={id}` es correcta; también lo
  es la distinción entre grupo sintáctico y semántico.
- **Descomposición por bloques del all-different.** La prueba es correcta: los
  bloques `J_{k!,(n-k)!}` tienen soportes disjuntos, el rango es `C(n,k)` y el
  espectro singular no nulo es plano.
- **Cografos.** La recurrencia por intervalos `[p,n]`, el teorema de decisión y
  la reconstrucción se verificaron contra Held–Karp en 700 cografos aleatorios.
- **Álgebra de firmas.** El teorema de corrección es la DP estándar de árbol y
  es correcto; la proposición de compresión es un criterio condicional, no un
  algoritmo universal.

## Comprobaciones experimentales

Se ejecutaron los scripts del paquete y se guardaron las salidas en
`paper_material/outputs/`. Las tablas de simetría, rango, tensor completo,
cografos y codificaciones se corresponden con esas salidas. Las comprobaciones
no sustituyen una auditoría independiente; son reproducibles, no una validación
externa.

## Correcciones aplicadas

1. Cota de OpenAI corregida y resumen/Lean separados.
2. Secciones de estado experimental y reproducibilidad actualizadas al paquete.
3. Alcance de la DP de firmas acotado explícitamente.
4. Esquemas de join aclarados.
5. Orientación de caminos aclarada.
6. Complejidad de reconstrucción en cografos separada de la decisión.

## Conclusión

La versión corregida elimina el error factual y las afirmaciones de
reproducibilidad incorrectas. No se encontró un error en los teoremas de rango,
Burnside firmado, SAT-ORBIT o cografos. El manuscrito sigue sin afirmar
`P=NP`; sus contribuciones son estructurales y condicionales.
