"""
Isomorfismo de grafos: reducción GI -> SI y búsqueda exacta por individualización.

Correcciones respecto de la versión anterior:
  - Resolver cada órbita o bloque por separado no garantiza que las soluciones
    parciales se combinen en una sola permutación. Ahora se buscan elementos
    reales del grupo que respeten todas las decisiones de individualización.
  - El estabilizador de un punto se trataba como subgrupo cuando en realidad
    es un coseto; cerrar ese coseto agrandaba el grupo. Aquí se filtran los
    elementos del grupo, sin cerrar cosetos.
  - La permutación de vértices se recupera directamente de la permutación de
    pares encontrada, en lugar de repetir una búsqueda sobre la matriz.

La implementación materializa S_n^(2), de tamaño n!, por lo que es exacta
para n pequeño. No es la versión polinómica completa de Babai; conserva la
reducción GI -> SI y la idea de individualización.
"""

from collections import Counter
from itertools import combinations

MAX_N = 8


def _compose(p, q):
    """Composición (p ∘ q)(i) = p[q[i]]."""
    return tuple(p[q[i]] for i in range(len(p)))


def _identity(n):
    return tuple(range(n))


def _apply_perm(string, permutation):
    """Mueve el símbolo de la posición i a la posición permutation[i]."""
    result = [""] * len(string)
    for position, image in enumerate(permutation):
        result[image] = string[position]
    return "".join(result)


class PermGroup:
    """Grupo finito de permutaciones dado por generadores."""

    def __init__(self, n, generators):
        self.n = n
        identity = _identity(n)
        self.generators = []
        for generator in generators:
            generator = tuple(generator)
            if generator != identity:
                self.generators.append(generator)
        self._elements = None

    @property
    def elements(self):
        if self._elements is None:
            self._elements = self._closure()
        return self._elements

    def _closure(self):
        identity = _identity(self.n)
        seen = {identity}
        frontier = [identity]
        while frontier:
            following = []
            for element in frontier:
                for generator in self.generators:
                    product = _compose(generator, element)
                    if product not in seen:
                        seen.add(product)
                        following.append(product)
            frontier = following
        return seen


def _pairs(n):
    return list(combinations(range(n), 2))


def induced_pair_group(n):
    """Imagen de S_n en su acción sobre los pares no ordenados de vértices."""
    pairs = _pairs(n)
    pair_index = {pair: index for index, pair in enumerate(pairs)}
    generators = []

    for position in range(n - 1):
        vertex_perm = list(range(n))
        vertex_perm[position], vertex_perm[position + 1] = (
            vertex_perm[position + 1],
            vertex_perm[position],
        )
        pair_perm = []
        for first, second in pairs:
            image_first = vertex_perm[first]
            image_second = vertex_perm[second]
            if image_first > image_second:
                image_first, image_second = image_second, image_first
            pair_perm.append(pair_index[(image_first, image_second)])
        generators.append(tuple(pair_perm))

    return PermGroup(len(pairs), generators)


def _search(x, y, candidates, remaining):
    """Individualiza puntos conservando solo los candidatos compatibles."""
    if not remaining:
        return candidates[0]

    # Elegir el punto con menos imágenes posibles reduce la ramificación.
    point = min(
        remaining,
        key=lambda candidate_point: len(
            {permutation[candidate_point] for permutation in candidates}
        ),
    )

    for image in sorted({permutation[point] for permutation in candidates}):
        if x[point] != y[image]:
            continue
        compatible = [
            permutation
            for permutation in candidates
            if permutation[point] == image
        ]
        if compatible:
            result = _search(x, y, compatible, remaining - {point})
            if result is not None:
                return result
    return None


def si_solve(x, y, group):
    """Busca g en `group` tal que g(x) = y. Devuelve g o None."""
    if len(x) != len(y) or len(x) != group.n:
        raise ValueError("Las cadenas y el grupo deben actuar sobre el mismo conjunto.")
    if Counter(x) != Counter(y):
        return None

    candidates = list(group.elements)
    if not candidates:
        return None

    result = _search(x, y, candidates, set(range(group.n)))
    if result is not None and _apply_perm(x, result) == y:
        return result
    return None


def pair_perm_to_vertex_perm(n, pair_perm):
    """Recupera la permutación de vértices que induce `pair_perm`."""
    if n <= 2:
        return _identity(n)

    pairs = _pairs(n)
    pair_index = {pair: index for index, pair in enumerate(pairs)}

    # Las imágenes de {0,1} y {0,2} se cortan exactamente en la imagen de 0.
    image_01 = pairs[pair_perm[pair_index[(0, 1)]]]
    image_02 = pairs[pair_perm[pair_index[(0, 2)]]]
    common = set(image_01) & set(image_02)
    if len(common) != 1:
        return None

    image_of_zero = common.pop()
    permutation = [-1] * n
    permutation[0] = image_of_zero

    for vertex in range(1, n):
        image = pairs[pair_perm[pair_index[(0, vertex)]]]
        others = [value for value in image if value != image_of_zero]
        if len(others) != 1:
            return None
        permutation[vertex] = others[0]

    if len(set(permutation)) != n:
        return None
    return tuple(permutation)


def is_isomorphism(n, x, y, permutation):
    """Comprueba que `permutation` lleva las aristas de x a las de y."""
    if permutation is None:
        return False
    pairs = _pairs(n)
    pair_index = {pair: index for index, pair in enumerate(pairs)}

    for position, (first, second) in enumerate(pairs):
        image_first = permutation[first]
        image_second = permutation[second]
        if image_first > image_second:
            image_first, image_second = image_second, image_first
        if y[pair_index[(image_first, image_second)]] != x[position]:
            return False
    return True


def babai_graph_isomorphism(n, x, y, verbose=False):
    """
    Isomorfismo de grafos sobre (n, x, y), con x e y en el orden lexicográfico
    de los pares (0,1), (0,2), ..., (n-2,n-1).
    Devuelve (True, permutación_de_vértices) o (False, None).
    """
    if n < 0:
        raise ValueError("n debe ser no negativo.")
    expected = n * (n - 1) // 2
    if len(x) != expected or len(y) != expected:
        raise ValueError("x e y deben medir %d bits para n=%d." % (expected, n))
    if any(character not in "01" for character in x + y):
        raise ValueError("x e y deben ser cadenas binarias.")
    if n > MAX_N:
        raise ValueError(
            "Esta implementación enumera S_n^(2); usa n <= %d." % MAX_N
        )

    if Counter(x) != Counter(y):
        return (False, None)

    group = induced_pair_group(n)
    if verbose:
        print("n=%d, pares=%d, |S_n^(2)|=%d" % (n, expected, len(group.elements)))

    pair_perm = si_solve(x, y, group)
    if pair_perm is None:
        if verbose:
            print("No hay permutación de pares que lleve x a y.")
        return (False, None)

    permutation = pair_perm_to_vertex_perm(n, pair_perm)
    if not is_isomorphism(n, x, y, permutation):
        raise RuntimeError("La permutación de pares no produjo un isomorfismo de vértices.")

    if verbose:
        print("isomorfismo encontrado: %r" % (permutation,))
    return (True, permutation)


def _relabel_string(n, x, permutation):
    """Aplica una permutación de vértices a la cadena de adyacencia x."""
    pairs = _pairs(n)
    pair_index = {pair: index for index, pair in enumerate(pairs)}
    relabeled = ["0"] * len(pairs)

    for position, (first, second) in enumerate(pairs):
        image_first = permutation[first]
        image_second = permutation[second]
        if image_first > image_second:
            image_first, image_second = image_second, image_first
        relabeled[pair_index[(image_first, image_second)]] = x[position]
    return "".join(relabeled)


def _run_tests():
    assert babai_graph_isomorphism(3, "111", "101") == (False, None)

    ok, permutation = babai_graph_isomorphism(4, "100101", "010011")
    assert ok and is_isomorphism(4, "100101", "010011", permutation)

    ok, permutation = babai_graph_isomorphism(4, "101101", "110101")
    assert not ok and permutation is None
    
    import random

    rng = random.Random(0)
    for n in range(3, 8):
        for _ in range(10):
            x = "".join(
                rng.choice("01") for _ in range(n * (n - 1) // 2)
            )
            permutation = list(range(n))
            rng.shuffle(permutation)
            y = _relabel_string(n, x, tuple(permutation))
            ok, found = babai_graph_isomorphism(n, x, y)
            assert ok and is_isomorphism(n, x, y, found)

    print("babai.py: todas las pruebas pasan.")


if __name__ == "__main__":
    _run_tests()
