"""
Generador de instancias CNF variadas en formato DIMACS.

Tipos:
    ksat       CNF aleatoria con cláusulas de ancho k.
    mixed      CNF aleatoria con anchos variables.
    balanced   CNF balanceada: un literal por variable en cada cláusula.
    planted    CNF k-SAT con una asignación satisfaciente conocida.
    php        principio del palomar (insatisfacible si palomas > agujeros).
    suite      conjunto de instancias variadas en un directorio.

Sin dependencias externas.
"""

import argparse
import os
import random
import sys

from sat_equation import formula_satisfied, to_dimacs, write_dimacs


def _random_clause(rng, n, width):
    if not 1 <= width <= n:
        raise ValueError("Se requiere 1 <= ancho <= N.")
    variables = rng.sample(range(1, n + 1), width)
    return [variable if rng.getrandbits(1) else -variable for variable in variables]


def _unique_clauses(m, make_clause):
    """Genera m cláusulas distintas (salvo orden de literales)."""
    if m < 0:
        raise ValueError("M debe ser no negativo.")
    clauses = []
    seen = set()
    attempts = 0
    limit = max(1000, 200 * m)

    while len(clauses) < m:
        clause = make_clause()
        key = tuple(sorted(clause))
        if key not in seen:
            seen.add(key)
            clauses.append(clause)
        attempts += 1
        if attempts > limit:
            raise ValueError(
                "No se pudieron generar %d cláusulas distintas; "
                "reduce M o amplía el espacio de cláusulas." % m
            )
    return clauses


def random_kcnf(n, m, width, seed=None):
    """CNF aleatoria con m cláusulas de ancho exacto `width`."""
    if n < 1:
        raise ValueError("N debe ser al menos 1.")
    if not 1 <= width <= n:
        raise ValueError("Se requiere 1 <= ancho <= N.")
    rng = random.Random(seed)
    return _unique_clauses(m, lambda: _random_clause(rng, n, width))


def random_mixed_cnf(n, m, seed=None, min_width=1, max_width=None):
    """CNF aleatoria con anchos elegidos uniformemente en [min_width, max_width]."""
    if n < 1:
        raise ValueError("N debe ser al menos 1.")
    if max_width is None:
        max_width = n
    if not 1 <= min_width <= max_width <= n:
        raise ValueError("Se requiere 1 <= ancho mínimo <= ancho máximo <= N.")
    rng = random.Random(seed)

    def make_clause():
        width = rng.randint(min_width, max_width)
        return _random_clause(rng, n, width)

    return _unique_clauses(m, make_clause)


def balanced_cnf(n, m, seed=None):
    """CNF balanceada: cada cláusula contiene exactamente un literal por variable."""
    if n < 1:
        raise ValueError("N debe ser al menos 1.")
    if m > (1 << n):
        raise ValueError("Una CNF balanceada sobre N variables tiene a lo sumo 2^N cláusulas.")
    rng = random.Random(seed)

    def make_clause():
        return [
            variable if rng.getrandbits(1) else -variable
            for variable in range(1, n + 1)
        ]

    return _unique_clauses(m, make_clause)


def planted_cnf(n, m, width, seed=None):
    """
    CNF k-SAT con una asignación satisfaciente plantada.
    Devuelve (asignación_plantada, cláusulas).
    """
    if n < 1:
        raise ValueError("N debe ser al menos 1.")
    if not 1 <= width <= n:
        raise ValueError("Se requiere 1 <= ancho <= N.")
    rng = random.Random(seed)
    planted = tuple(rng.getrandbits(1) for _ in range(n))

    def make_clause():
        variables = rng.sample(range(1, n + 1), width)
        pivot = variables[rng.randrange(width)]
        clause = []
        for variable in variables:
            if variable == pivot:
                literal = variable if planted[variable - 1] == 1 else -variable
            else:
                literal = variable if rng.getrandbits(1) else -variable
            clause.append(literal)
        return clause

    clauses = _unique_clauses(m, make_clause)
    if not formula_satisfied(n, clauses, planted):
        raise AssertionError("La asignación plantada no satisface la instancia generada.")
    return planted, clauses


def pigeonhole_cnf(pigeons, holes):
    """
    Principio del palomar: cada paloma en al menos un agujero y ningún
    agujero con dos palomas. Es insatisfacible si pigeons > holes.
    """
    if pigeons < 0 or holes < 0:
        raise ValueError("El número de palomas y agujeros debe ser no negativo.")

    def variable(pigeon, hole):
        return pigeon * holes + hole + 1

    clauses = []
    for pigeon in range(pigeons):
        clauses.append([variable(pigeon, hole) for hole in range(holes)])
    for hole in range(holes):
        for first in range(pigeons):
            for second in range(first + 1, pigeons):
                clauses.append(
                    [-variable(first, hole), -variable(second, hole)]
                )
    return pigeons * holes, clauses


def generate_suite(directory, seed=0):
    """Escribe un conjunto variado de instancias y devuelve sus descripciones."""
    os.makedirs(directory, exist_ok=True)
    specs = []

    def save(name, n, clauses, comment):
        path = os.path.join(directory, name)
        write_dimacs(path, n, clauses, comment=comment)
        specs.append((path, n, len(clauses)))

    save(
        "2sat_n20_m40.cnf",
        20,
        random_kcnf(20, 40, 2, seed + 1),
        "2-SAT aleatoria; n=20; m=40; seed=%d" % (seed + 1),
    )
    save(
        "3sat_n10_m42.cnf",
        10,
        random_kcnf(10, 42, 3, seed + 2),
        "3-SAT aleatoria; n=10; m=42; seed=%d" % (seed + 2),
    )
    save(
        "3sat_n15_m64.cnf",
        15,
        random_kcnf(15, 64, 3, seed + 3),
        "3-SAT aleatoria; n=15; m=64; seed=%d" % (seed + 3),
    )
    save(
        "3sat_n20_m85.cnf",
        20,
        random_kcnf(20, 85, 3, seed + 4),
        "3-SAT aleatoria; n=20; m=85; seed=%d" % (seed + 4),
    )
    save(
        "4sat_n12_m50.cnf",
        12,
        random_kcnf(12, 50, 4, seed + 5),
        "4-SAT aleatoria; n=12; m=50; seed=%d" % (seed + 5),
    )
    save(
        "mixed_n12_m30.cnf",
        12,
        random_mixed_cnf(12, 30, seed + 6, min_width=1, max_width=6),
        "CNF mixta; n=12; m=30; anchos=1..6; seed=%d" % (seed + 6),
    )
    save(
        "balanced_n5_m10.cnf",
        5,
        balanced_cnf(5, 10, seed + 7),
        "CNF balanceada; n=5; m=10; seed=%d" % (seed + 7),
    )
    save(
        "planted_n15_m60.cnf",
        15,
        planted_cnf(15, 60, 3, seed + 8)[1],
        "3-SAT plantada (SAT por construcción); n=15; m=60; seed=%d" % (seed + 8),
    )

    n, clauses = pigeonhole_cnf(4, 3)
    save("php_4_3.cnf", n, clauses, "PHP: 4 palomas, 3 agujeros (UNSAT)")
    n, clauses = pigeonhole_cnf(5, 4)
    save("php_5_4.cnf", n, clauses, "PHP: 5 palomas, 4 agujeros (UNSAT)")

    return specs


def _emit(n, clauses, path, comment):
    if path is None:
        sys.stdout.write(to_dimacs(n, clauses, comment=comment))
        return
    directory = os.path.dirname(os.path.abspath(path))
    if directory:
        os.makedirs(directory, exist_ok=True)
    write_dimacs(path, n, clauses, comment=comment)
    print("escrito %s: N=%d, cláusulas=%d" % (path, n, len(clauses)))


def main(argv=None):
    parser = argparse.ArgumentParser(
        description="Generador de instancias CNF variadas en formato DIMACS."
    )
    parser.add_argument(
        "--type",
        choices=[
            "2sat",
            "3sat",
            "4sat",
            "ksat",
            "mixed",
            "balanced",
            "planted",
            "php",
            "suite",
        ],
        default="3sat",
        help="tipo de instancia (por defecto: 3sat)",
    )
    parser.add_argument("--n", type=int, default=20, help="número de variables")
    parser.add_argument("--m", type=int, default=85, help="número de cláusulas")
    parser.add_argument("--k", type=int, default=3, help="ancho para ksat/planted")
    parser.add_argument("--seed", type=int, default=0, help="semilla aleatoria")
    parser.add_argument("--min-len", type=int, default=1, help="ancho mínimo en mixed")
    parser.add_argument("--max-len", type=int, default=None, help="ancho máximo en mixed")
    parser.add_argument("--pigeons", type=int, default=5, help="palomas en php")
    parser.add_argument("--holes", type=int, default=4, help="agujeros en php")
    parser.add_argument("--out", "-o", default=None, help="archivo DIMACS de salida")
    parser.add_argument(
        "--out-dir",
        default="instancias",
        help="directorio de salida para --type suite",
    )
    args = parser.parse_args(argv)

    try:
        if args.type == "suite":
            specs = generate_suite(args.out_dir, args.seed)
            for path, n, m in specs:
                print("%s: N=%d, cláusulas=%d" % (path, n, m))
            return

        n = args.n
        if args.type in ("2sat", "3sat", "4sat"):
            width = int(args.type[0])
            clauses = random_kcnf(n, args.m, width, args.seed)
            comment = "%d-SAT aleatoria; n=%d; m=%d; seed=%d" % (
                width,
                n,
                args.m,
                args.seed,
            )
        elif args.type == "ksat":
            clauses = random_kcnf(n, args.m, args.k, args.seed)
            comment = "%d-SAT aleatoria; n=%d; m=%d; seed=%d" % (
                args.k,
                n,
                args.m,
                args.seed,
            )
        elif args.type == "mixed":
            clauses = random_mixed_cnf(
                n, args.m, args.seed, args.min_len, args.max_len
            )
            comment = "CNF mixta; n=%d; m=%d; anchos=%d..%s; seed=%d" % (
                n,
                args.m,
                args.min_len,
                args.max_len if args.max_len is not None else n,
                args.seed,
            )
        elif args.type == "balanced":
            clauses = balanced_cnf(n, args.m, args.seed)
            comment = "CNF balanceada; n=%d; m=%d; seed=%d" % (
                n,
                args.m,
                args.seed,
            )
        elif args.type == "planted":
            _, clauses = planted_cnf(n, args.m, args.k, args.seed)
            comment = "%d-SAT plantada (SAT); n=%d; m=%d; seed=%d" % (
                args.k,
                n,
                args.m,
                args.seed,
            )
        else:
            n, clauses = pigeonhole_cnf(args.pigeons, args.holes)
            comment = "PHP; palomas=%d; agujeros=%d" % (
                args.pigeons,
                args.holes,
            )

        _emit(n, clauses, args.out, comment)
    except ValueError as error:
        parser.error(str(error))


if __name__ == "__main__":
    main()
