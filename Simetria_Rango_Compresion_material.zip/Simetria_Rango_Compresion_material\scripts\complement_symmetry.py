"""
Simetría 0/1 en la Ecuación SAT: dualidad de posición y simetrías con signos.

Hechos que se comprueban:
  - Negar todas las variables de F produce F† con
        S(F†) = reverso_de_bits(S(F)).
    No es un simple cambio de nombre: complementa la asignación y mueve la
    posición al espejo 2^n - 1 - k.
  - Si F es autocomplementaria (invariante bajo x -> 1-x), S(F) es un
    palíndromo y basta calcular la mitad de los bits/órbitas.
  - Una simetría con signos que preserve F (por ejemplo, voltear solo x1)
    también reduce K; no es una simetría de variables sin signos.
  - Para una CNF arbitraria no hay tal simetría; K no se reduce.

Este módulo no modifica los anteriores.
"""

import time

from sat_equation import assignment_at, formula_satisfied, sat_equation
from cnf_generator import pigeonhole_cnf, random_kcnf
import sat_symmetry as sym


def negate_all_variables(clauses):
    """F†(x) = F(1-x); se niegan todos los literales."""
    return [[-literal for literal in clause] for clause in clauses]


def bit_reverse(S, n):
    """Invierte los 2^n bits de S: el bit k pasa a 2^n - 1 - k."""
    width = 1 << n
    bits = format(S, "0%db" % width)[-width:]
    return int(bits[::-1], 2)


def is_self_complementary_syntactic(n, clauses):
    """F y F† tienen el mismo conjunto de cláusulas."""
    return sym.clause_set(clauses) == sym.clause_set(negate_all_variables(clauses))


def is_self_complementary_semantic(n, clauses):
    """c(x) = c(1-x) para todas las asignaciones. Sólo para n pequeño."""
    for position in range(1 << n):
        assignment = assignment_at(position, n)
        complement = tuple(1 - bit for bit in assignment)
        if formula_satisfied(n, clauses, assignment) != formula_satisfied(
            n, clauses, complement
        ):
            return False
    return True


def signed_flip_preserves(n, clauses, flip_variables):
    """Comprueba si negar las variables del conjunto preserva la CNF."""
    flipped = []
    flip_set = set(flip_variables)
    for clause in clauses:
        new_clause = []
        for literal in clause:
            variable = abs(literal)
            new_literal = literal
            if variable in flip_set:
                new_literal = -literal
            new_clause.append(new_literal)
        flipped.append(new_clause)
    return sym.clause_set(clauses) == sym.clause_set(flipped)


def orbit_partition_extended(n, clauses, variable_generators, flip_masks):
    """
    Órbitas de {0,1}^n bajo permutaciones de variables y volteos de bits.
    Devuelve (representantes, tamaños, válido_para_c).
    """
    total = 1 << n
    parent = list(range(total))
    rank = [0] * total

    def find(node):
        while parent[node] != node:
            parent[node] = parent[parent[node]]
            node = parent[node]
        return node

    def union(first, second):
        root_first = find(first)
        root_second = find(second)
        if root_first == root_second:
            return
        if rank[root_first] < rank[root_second]:
            root_first, root_second = root_second, root_first
        parent[root_second] = root_first
        if rank[root_first] == rank[root_second]:
            rank[root_first] += 1

    for swaps in variable_generators:
        for position in range(total):
            union(position, sym.apply_swaps(position, n, swaps))
    for mask in flip_masks:
        for position in range(total):
            union(position, position ^ mask)

    root_to_id = {}
    representatives = []
    sizes = []
    for position in range(total):
        root = find(position)
        orbit_id = root_to_id.get(root)
        if orbit_id is None:
            orbit_id = len(representatives)
            root_to_id[root] = orbit_id
            representatives.append(position)
            sizes.append(0)
        sizes[orbit_id] += 1

    # Comprobar que la coloración es constante en cada órbita.
    colors = {}
    for position in range(total):
        assignment = assignment_at(position, n)
        color = 0 if formula_satisfied(n, clauses, assignment) else 1
        orbit_id = root_to_id[find(position)]
        if orbit_id in colors and colors[orbit_id] != color:
            return representatives, sizes, False
        colors[orbit_id] = color
    return representatives, sizes, True


def quotient_bits(n, clauses, representatives):
    bits = []
    for representative in representatives:
        assignment = assignment_at(representative, n)
        bits.append(0 if formula_satisfied(n, clauses, assignment) else 1)
    return bits


def analyze(name, n, clauses, variable_generators, flip_variables):
    flip_masks = [sum(1 << (n - variable) for variable in flip_variables)]
    started = time.perf_counter()
    base_reps, _, _ = orbit_partition_extended(
        n, clauses, variable_generators, []
    )
    extended_reps, _, extended_valid = orbit_partition_extended(
        n, clauses, variable_generators, flip_masks
    )
    base_bits = quotient_bits(n, clauses, base_reps)
    extended_bits = quotient_bits(n, clauses, extended_reps) if extended_valid else None
    syntactic = signed_flip_preserves(n, clauses, flip_variables)
    elapsed = time.perf_counter() - started
    return {
        "name": name,
        "n": n,
        "m": len(clauses),
        "base_k": len(base_reps),
        "extended_k": len(extended_reps) if extended_valid else None,
        "base_status": "UNSAT" if all(base_bits) else "SAT",
        "extended_status": (
            "UNSAT" if extended_bits is not None and all(extended_bits) else
            "SAT" if extended_bits is not None else "—"
        ),
        "extended_valid": extended_valid,
        "syntactic": syntactic,
        "time": elapsed,
    }


def print_table(rows):
    print("| instancia | n | m | K sin signos | K con signos | simetría sintáctica | invariancia semántica | estado | tiempo (s) |")
    print("|---|---:|---:|---:|---:|---|---|---|---:|")
    for row in rows:
        print(
            "| %s | %d | %d | %d | %s | %s | %s | %s | %.3f |"
            % (
                row["name"],
                row["n"],
                row["m"],
                row["base_k"],
                row["extended_k"] if row["extended_k"] is not None else "—",
                "sí" if row["syntactic"] else "no",
                "sí" if row["extended_valid"] else "no",
                row["base_status"],
                row["time"],
            )
        )


def mirror_table():
    print("### Identidad espejo S(F†) = reverso(S(F))")
    examples = []

    n = 2
    examples.append(("F=(x1)", n, [[1]]))
    n = 4
    examples.append(("paridad impar", n, sym.parity_formula(n, {1})))
    n = 6
    examples.append(("paridad impar", n, sym.parity_formula(n, {1})))
    n = 5
    examples.append(("aleatoria", n, random_kcnf(n, 12, 3, seed=3)))

    print("| instancia | n | S(F†) = reverso(S(F)) | autocomplementaria sintáctica |")
    print("|---|---:|---|---|")
    for name, n, clauses in examples:
        S = sat_equation(n, clauses)
        flipped = negate_all_variables(clauses)
        S_flipped = sat_equation(n, flipped)
        ok = S_flipped == bit_reverse(S, n)
        syntactic = is_self_complementary_syntactic(n, clauses)
        print(
            "| %s | %d | %s | %s |"
            % (name, n, "sí" if ok else "no", "sí" if syntactic else "no")
        )


def main():
    mirror_table()

    rows = []

    # F = (x1): el complemento global no preserva F.
    n = 2
    clauses = [[1]]
    rows.append(
        analyze(
            "F=(x1)",
            n,
            clauses,
            [],
            list(range(1, n + 1)),
        )
    )

    # F = (x2): voltear solo x1 preserva F.
    n = 2
    clauses = [[1, 2], [-1, 2]]
    rows.append(
        analyze(
            "F=(x1∨x2)∧(¬x1∨x2)=x2",
            n,
            clauses,
            [],
            [1],
        )
    )

    # F = (x1∨x2)∧(¬x1∨¬x2): autocomplementaria, SAT.
    n = 2
    clauses = [[1, 2], [-1, -2]]
    rows.append(
        analyze(
            "F=(x1∨x2)∧(¬x1∨¬x2)",
            n,
            clauses,
            [[(0, 1)]],
            list(range(1, n + 1)),
        )
    )

    # Paridad con n par: autocomplementaria.
    for n in [10, 12]:
        clauses = sym.parity_formula(n, {1})
        rows.append(
            analyze(
                "paridad impar(n=%d)" % n,
                n,
                clauses,
                sym.parity_generators(n),
                list(range(1, n + 1)),
            )
        )

    # Paridad con n impar: el complemento global no preserva F.
    n = 11
    clauses = sym.parity_formula(n, {1})
    rows.append(
        analyze(
            "paridad impar(n=%d)" % n,
            n,
            clauses,
            sym.parity_generators(n),
            list(range(1, n + 1)),
        )
    )

    # PHP: no es autocomplementaria sintácticamente.
    n, clauses = pigeonhole_cnf(4, 3)
    rows.append(
        analyze(
            "PHP(4,3)",
            n,
            clauses,
            sym.php_generators(4, 3),
            list(range(1, n + 1)),
        )
    )

    # 3-SAT aleatoria: sin simetría de signos esperada.
    n = 8
    clauses = random_kcnf(n, 34, 3, seed=0)
    rows.append(
        analyze(
            "3-SAT aleatoria(n=8)",
            n,
            clauses,
            [],
            list(range(1, n + 1)),
        )
    )

    print("\n### K con y sin simetrías de signo")
    print_table(rows)


if __name__ == "__main__":
    main()
