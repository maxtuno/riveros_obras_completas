"""
Verificación y cuantificación de mejoras a los algoritmos que refutan ETH.

No implementa los algoritmos completos. Verifica la identidad de los ocho
cuadrados usada por Anthropic y calcula los exponentes de las cotas para
comparar mejoras posibles.
"""

import itertools
import math


def phi(p, q):
    value = 0
    for i in range(3):
        for j in range(i, 3):
            value += p[i] * q[j]
    value += q[0] * p[1] * p[2]
    value += p[0] * q[1] * p[2]
    value += p[0] * p[1] * q[2]
    return value % 2


def sigma(p, q):
    return -1 if phi(p, q) else 1


def xor3(a, b, c, d):
    return tuple(a[i] ^ b[i] ^ c[i] ^ d[i] for i in range(3))


def check_eight_square():
    blocks = list(itertools.product((0, 1), repeat=3))
    checks = 0
    for x in blocks:
        for y in blocks:
            for u in blocks:
                for v in blocks:
                    left = 2 * (1 if x == v else 0) * (1 if y == u else 0)
                    right = (1 if xor3(x, y, u, v) == (0, 0, 0) else 0) * (
                        sigma(x, y) * sigma(v, u) + sigma(x, u) * sigma(v, y)
                    )
                    if left != right:
                        raise AssertionError((x, y, u, v, left, right))
                    checks += 1
    return checks


def exponent_openai(n):
    """Cota explícita del teorema: n log log n / sqrt(log n)."""
    if n < 3:
        return 0.0
    return n * math.log(math.log(n)) / math.sqrt(math.log(n))


def exponent_anthropic_m(m, k=3):
    """Cota en m: k m / sqrt(log m), con k=3 para 3-CNF."""
    if m < 3:
        return 0.0
    return k * m / math.sqrt(math.log(m))


def exponent_anthropic_n(n, k=3):
    """Cota en n: k^2 n log log n / sqrt(log n)."""
    if n < 3:
        return 0.0
    return k * k * n * math.log(math.log(n)) / math.sqrt(math.log(n))


def main():
    checks = check_eight_square()
    print("Identidad de ocho cuadrados verificada en", checks, "configuraciones.")

    print("\nConstantes de la recursión de Anthropic:")
    print("  rho actual (ocho cuadrados): 11/12 =", 11 / 12)
    print("  rho citado con Hrubeš:       ~0.905")
    print("  mejora relativa del exponente:", 1 - 0.905 / (11 / 12))

    print("\n| n | OpenAI n loglog n/√log n | Anthropic n (k=3) | Anthropic m=n (k=3) | Anthropic m=3n (k=3) |")
    print("|---:|---:|---:|---:|---:|")
    for n in [10**3, 10**6, 10**9]:
        print(
            "| %d | %.4f | %.4f | %.4f | %.4f |"
            % (
                n,
                exponent_openai(n),
                exponent_anthropic_n(n),
                exponent_anthropic_m(n),
                exponent_anthropic_m(3 * n),
            )
        )


if __name__ == "__main__":
    main()
