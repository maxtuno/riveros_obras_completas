"""
Cálculo genérico de K = número de órbitas de {0,1}^n bajo Aut(F).

No se usa el nombre de la familia. El algoritmo recibe una CNF cualquiera y
busca sus automorfismos de variables con un backtracking que hace coincidir
cláusulas y firmas. Con el grupo encontrado, K se obtiene por Burnside:

    K = (1/|G|) * suma_{g en G} 2^{c(g)},

donde c(g) es el número de ciclos de g sobre las variables.

Esto es una prueba de concepto, no un motor de canonicalización escalable:
en el peor caso enumerar Aut(F) es tan difícil como el isomorfismo de grafos,
y el grupo puede ser exponencial. Para grupos grandes se necesitan generadores
y algoritmos de teoría de grupos (Schreier-Sims), no la enumeración completa.
"""

import math
import random
import time

from cnf_generator import pigeonhole_cnf, random_kcnf
from sat_symmetry import burnside_orbit_count


def _sign(literal):
    return 1 if literal > 0 else -1


def obfuscate(n, clauses, seed=0):
    """
    Renombra variables y baraja cláusulas. La familia sigue siendo la misma,
    pero el algoritmo genérico no ve ninguna etiqueta de familia.
    """
    rng = random.Random(seed)
    permutation = list(range(1, n + 1))
    rng.shuffle(permutation)
    rename = {old: new for old, new in zip(range(1, n + 1), permutation)}
    new_clauses = []
    for clause in clauses:
        new_clauses.append(
            [(_sign(literal)) * rename[abs(literal)] for literal in clause]
        )
    rng.shuffle(new_clauses)
    return new_clauses


def _prepare(n, clauses):
    clause_sets = [frozenset(clause) for clause in clauses]
    var_clauses = {variable: [] for variable in range(1, n + 1)}
    for index, clause in enumerate(clauses):
        for literal in clause:
            var_clauses[abs(literal)].append(index)

    signatures = {}
    for variable in range(1, n + 1):
        positives = 0
        negatives = 0
        lengths = []
        for index in var_clauses[variable]:
            clause = clauses[index]
            lengths.append(len(clause))
            for literal in clause:
                if abs(literal) == variable:
                    if literal > 0:
                        positives += 1
                    else:
                        negatives += 1
        signatures[variable] = (positives, negatives, tuple(sorted(lengths)))

    candidates = []
    for clause in clauses:
        positives = sum(1 for literal in clause if literal > 0)
        negatives = len(clause) - positives
        candidates.append(
            [
                index
                for index, other in enumerate(clauses)
                if len(other) == len(clause)
                and sum(1 for literal in other if literal > 0) == positives
                and sum(1 for literal in other if literal < 0) == negatives
            ]
        )

    return clause_sets, var_clauses, signatures, candidates


def _search_automorphisms(n, clauses, limit=None):
    """
    Enumera automorfismos de variables. Devuelve (lista, completo).
    Cada automorfismo es una tupla 0-based: image[i] es la imagen de i.
    """
    clause_sets, var_clauses, signatures, candidates = _prepare(n, clauses)
    clause_set = set(clause_sets)
    total_clauses = len(clauses)

    def candidate_clauses(index, mapping, used):
        clause = clauses[index]
        partial = []
        unmapped = []
        for literal in clause:
            variable = abs(literal)
            if variable in mapping:
                partial.append(_sign(literal) * mapping[variable])
            else:
                unmapped.append(literal)
        partial_set = set(partial)
        result = []
        for other_index in candidates[index]:
            other = clause_sets[other_index]
            if not partial_set.issubset(other):
                continue
            rest = [literal for literal in other if literal not in partial_set]
            if len(rest) != len(unmapped):
                continue
            if any(abs(literal) in used for literal in rest):
                continue
            if sorted(_sign(literal) for literal in rest) != sorted(
                _sign(literal) for literal in unmapped
            ):
                continue
            result.append(other_index)
        return result

    def domains(variable, mapping, used):
        result = []
        for image in range(1, n + 1):
            if image in used or signatures[image] != signatures[variable]:
                continue
            mapping[variable] = image
            used.add(image)
            valid = True
            for index in var_clauses[variable]:
                if not candidate_clauses(index, mapping, used):
                    valid = False
                    break
            used.remove(image)
            del mapping[variable]
            if valid:
                result.append(image)
        return result

    def is_full_automorphism(mapping):
        for clause in clauses:
            image = frozenset(
                _sign(literal) * mapping[abs(literal)] for literal in clause
            )
            if image not in clause_set:
                return False
        return True

    def search(mapping, used, found):
        if len(mapping) == n:
            if is_full_automorphism(mapping):
                found.append(tuple(mapping[variable] - 1 for variable in range(1, n + 1)))
            return
        if limit is not None and len(found) > limit:
            return

        best_variable = None
        best_domain = None
        for variable in range(1, n + 1):
            if variable in mapping:
                continue
            domain = domains(variable, mapping, used)
            if not domain:
                return
            if best_domain is None or len(domain) < len(best_domain):
                best_variable = variable
                best_domain = domain

        for image in best_domain:
            mapping[best_variable] = image
            used.add(image)
            if all(
                candidate_clauses(index, mapping, used)
                for index in range(total_clauses)
            ):
                search(mapping, used, found)
                if limit is not None and len(found) > limit:
                    used.remove(image)
                    del mapping[best_variable]
                    return
            used.remove(image)
            del mapping[best_variable]

    found = []
    search({}, set(), found)
    complete = limit is None or len(found) <= limit
    return found, complete


def generic_group_and_k(n, clauses, max_group=5000):
    """
    Devuelve (automorphisms, complete, K). Si el grupo supera max_group,
    no se enumera completo y K no se calcula por Burnside.
    """
    started = time.perf_counter()
    automorphisms, complete = _search_automorphisms(n, clauses, limit=max_group)
    elapsed = time.perf_counter() - started
    if not complete:
        return automorphisms, False, None, elapsed
    k = burnside_orbit_count(automorphisms)
    return automorphisms, True, k, elapsed


def print_table(rows):
    print("| instancia ofuscada | n | m | |Aut(F)| | completo | K (Burnside) | K de control | tiempo (s) |")
    print("|---|---:|---:|---:|---|---:|---:|---:|")
    for row in rows:
        print(
            "| %s | %d | %d | %d | %s | %s | %s | %.3f |"
            % (
                row["name"],
                row["n"],
                row["m"],
                len(row["automorphisms"]),
                "sí" if row["complete"] else "no",
                row["k"] if row["k"] is not None else "—",
                row["control_k"],
                row["time"],
            )
        )


def main():
    rows = []

    # PHP sin etiquetas: el algoritmo no sabe que es PHP.
    control = {(3, 2): 13, (4, 3): 87, (5, 4): 1053}
    for pigeons, holes in [(3, 2), (4, 3), (5, 4)]:
        n, clauses = pigeonhole_cnf(pigeons, holes)
        obfuscated = obfuscate(n, clauses, seed=pigeons * 10 + holes)
        automorphisms, complete, k, elapsed = generic_group_and_k(
            n, obfuscated, max_group=4000
        )
        rows.append(
            {
                "name": "PHP(%d,%d) ofuscado" % (pigeons, holes),
                "n": n,
                "m": len(obfuscated),
                "automorphisms": automorphisms,
                "complete": complete,
                "k": k,
                "control_k": control[(pigeons, holes)],
                "time": elapsed,
            }
        )

    # 3-SAT aleatoria: control negativo. K debe ser 2^n si el grupo es trivial.
    n = 8
    clauses = random_kcnf(n, 34, 3, seed=0)
    obfuscated = obfuscate(n, clauses, seed=99)
    automorphisms, complete, k, elapsed = generic_group_and_k(
        n, obfuscated, max_group=4000
    )
    rows.append(
        {
            "name": "3-SAT aleatoria(n=8) ofuscada",
            "n": n,
            "m": len(obfuscated),
            "automorphisms": automorphisms,
            "complete": complete,
            "k": k,
            "control_k": 1 << n,
            "time": elapsed,
        }
    )

    print_table(rows)
    print("\nK de control es el valor conocido de la familia; el algoritmo no lo usa.")


if __name__ == "__main__":
    main()
