"""
Camino hamiltoniano como condición sobre la superdiagonal de una matriz.

Idea del prototipo:
    Dada la matriz de adyacencia A de un grafo, ¿existe una permutación de
    filas/columnas que deje la primera superdiagonal llena de 1s?
    Esa condición es exactamente la existencia de un camino hamiltoniano.

Pregunta:
    ¿Se puede resolver comparando esa superdiagonal con 111... usando
    isomorfismo de grafos (Babai)?

La respuesta corta es no en general: la condición deja libres las demás
entradas de la matriz (un subcubo), mientras que el isomorfismo de grafos
compara la matriz completa con un único objetivo. La comparación exacta con
un camino solo reconoce grafos que son exactamente un camino.

Este módulo:
  - comprueba la equivalencia matriz <-> camino hamiltoniano;
  - compara con el test de isomorfismo exacto a un camino usando babai.py;
  - implementa el algoritmo estándar de programación dinámica O(n^2 2^n);
  - muestra contraejemplos y tiempos.
"""

import itertools
import random
import time

import babai


def pairs(n):
    return list(itertools.combinations(range(n), 2))


def edge_index(n):
    return {pair: index for index, pair in enumerate(pairs(n))}


def graph_string(n, edges):
    index = edge_index(n)
    bits = ["0"] * len(index)
    for first, second in edges:
        if first > second:
            first, second = second, first
        bits[index[(first, second)]] = "1"
    return "".join(bits)


def path_string(n):
    return graph_string(n, [(vertex, vertex + 1) for vertex in range(n - 1)])


def cycle_string(n):
    edges = [(vertex, (vertex + 1) % n) for vertex in range(n)]
    return graph_string(n, edges)


def has_edge(x, n, first, second):
    if first > second:
        first, second = second, first
    return x[edge_index(n)[(first, second)]] == "1"


def has_hamiltonian_path_bruteforce(n, x):
    for order in itertools.permutations(range(n)):
        if all(has_edge(x, n, order[i], order[i + 1]) for i in range(n - 1)):
            return order
    return None


def has_hamiltonian_path_dp(n, x):
    """
    Held--Karp: dp[mask][v] = hay un camino que visita exactamente mask y
    termina en v. Devuelve un orden o None.
    """
    if n == 0:
        return ()
    full = (1 << n) - 1
    parent = [[-1] * n for _ in range(1 << n)]
    dp = [[False] * n for _ in range(1 << n)]
    for vertex in range(n):
        dp[1 << vertex][vertex] = True

    for mask in range(1 << n):
        for last in range(n):
            if not dp[mask][last]:
                continue
            for nxt in range(n):
                if mask & (1 << nxt):
                    continue
                if not has_edge(x, n, last, nxt):
                    continue
                new_mask = mask | (1 << nxt)
                if not dp[new_mask][nxt]:
                    dp[new_mask][nxt] = True
                    parent[new_mask][nxt] = last

    end = None
    for vertex in range(n):
        if dp[full][vertex]:
            end = vertex
            break
    if end is None:
        return None

    order = []
    mask = full
    current = end
    while current != -1:
        order.append(current)
        previous = parent[mask][current]
        mask ^= 1 << current
        current = previous
    order.reverse()
    return tuple(order)


def exact_path_isomorphism(n, x):
    """Isomorfismo exacto al grafo camino P_n, usando babai.py."""
    if n > babai.MAX_N:
        raise ValueError("babai.py solo llega a n <= %d." % babai.MAX_N)
    return babai.babai_graph_isomorphism(n, x, path_string(n))[0]


def graph_automorphisms_bruteforce(n, x):
    """Aut(G) por enumeración, solo para n pequeño."""
    automorphisms = []
    for permutation in itertools.permutations(range(n)):
        if babai.is_isomorphism(n, x, x, permutation):
            automorphisms.append(permutation)
    return automorphisms


def vertex_orbit_representatives(n, automorphisms):
    seen = set()
    representatives = []
    for vertex in range(n):
        if vertex in seen:
            continue
        orbit = {permutation[vertex] for permutation in automorphisms}
        seen |= orbit
        representatives.append(min(orbit))
    return representatives


def has_hamiltonian_path_symmetry_reduced(n, x, automorphisms):
    """
    Reduce la búsqueda fijando el primer vértice a un representante de
    cada órbita de Aut(G). No es un algoritmo polinómico general.
    """
    representatives = vertex_orbit_representatives(n, automorphisms)
    for first in representatives:
        remaining = [vertex for vertex in range(n) if vertex != first]
        for rest in itertools.permutations(remaining):
            order = (first,) + rest
            if all(has_edge(x, n, order[i], order[i + 1]) for i in range(n - 1)):
                return order
    return None




def canonical_state(mask, endpoint, n, automorphisms):
    best = None
    best_mask = None
    best_endpoint = None
    for permutation in automorphisms:
        image_mask = 0
        for vertex in range(n):
            if mask & (1 << vertex):
                image_mask |= 1 << permutation[vertex]
        image_endpoint = permutation[endpoint]
        candidate = (image_mask, image_endpoint)
        if best is None or candidate < best:
            best = candidate
            best_mask = image_mask
            best_endpoint = image_endpoint
    return best_mask, best_endpoint


def standard_reachable_states(n, x):
    full = (1 << n) - 1
    seen = set()
    frontier = set()
    for vertex in range(n):
        state = (1 << vertex, vertex)
        seen.add(state)
        frontier.add(state)
    while frontier:
        following = set()
        for mask, endpoint in frontier:
            if mask == full:
                return True, len(seen)
            for nxt in range(n):
                if mask & (1 << nxt):
                    continue
                if not has_edge(x, n, endpoint, nxt):
                    continue
                state = (mask | (1 << nxt), nxt)
                if state not in seen:
                    seen.add(state)
                    following.add(state)
        frontier = following
    return any(mask == full for mask, _ in seen), len(seen)


def symmetry_reduced_dp(n, x, automorphisms):
    full = (1 << n) - 1
    seen = set()
    frontier = set()
    for vertex in range(n):
        state = canonical_state(1 << vertex, vertex, n, automorphisms)
        seen.add(state)
        frontier.add(state)
    while frontier:
        following = set()
        for mask, endpoint in frontier:
            if mask == full:
                return True, len(seen)
            for nxt in range(n):
                if mask & (1 << nxt):
                    continue
                if not has_edge(x, n, endpoint, nxt):
                    continue
                state = canonical_state(
                    mask | (1 << nxt), nxt, n, automorphisms
                )
                if state not in seen:
                    seen.add(state)
                    following.add(state)
        frontier = following
    return any(mask == full for mask, _ in seen), len(seen)


def symmetry_dp_table():
    n = 5
    print("\n| grafo | tamaño de Aut(G) | estados DP | estados cociente | reducción |")
    print("|---|---:|---:|---:|---:|")
    for name, x in example_graphs():
        automorphisms = graph_automorphisms_bruteforce(n, x)
        standard_has, standard_states = standard_reachable_states(n, x)
        reduced_has, reduced_states = symmetry_reduced_dp(n, x, automorphisms)
        if standard_has != reduced_has:
            raise AssertionError("La DP cociente falló en %s." % name)
        print(
            "| %s | %d | %d | %d | %.1f |"
            % (
                name,
                len(automorphisms),
                standard_states,
                reduced_states,
                standard_states / reduced_states,
            )
        )


def permute_graph_string(n, x, permutation):
    index = edge_index(n)
    bits = []
    for first, second in pairs(n):
        image_first = permutation[first]
        image_second = permutation[second]
        if image_first > image_second:
            image_first, image_second = image_second, image_first
        bits.append(x[index[(image_first, image_second)]])
    return "".join(bits)


def canonical_form(n, x):
    best = None
    best_permutation = None
    for permutation in itertools.permutations(range(n)):
        image = permute_graph_string(n, x, permutation)
        if best is None or image < best:
            best = image
            best_permutation = permutation
    return best, best_permutation


def canonical_superdiagonal(n, x):
    canonical, permutation = canonical_form(n, x)
    return (
        all(has_edge(canonical, n, vertex, vertex + 1) for vertex in range(n - 1)),
        permutation,
    )


def canonical_experiment(n):
    total_hp = 0
    canonical_hp = 0
    for mask in range(1 << (n * (n - 1) // 2)):
        x = "".join(
            "1" if (mask >> bit) & 1 else "0"
            for bit in range(n * (n - 1) // 2)
        )
        if has_hamiltonian_path_dp(n, x) is None:
            continue
        total_hp += 1
        if canonical_superdiagonal(n, x)[0]:
            canonical_hp += 1
    print(
        "n=%d: %d grafos con camino hamiltoniano; la superdiagonal canónica "
        "está llena en %d (falsos negativos=%d)."
        % (n, total_hp, canonical_hp, total_hp - canonical_hp)
    )


def example_graphs():
    n = 5
    return [
        (
            "P5",
            graph_string(n, [(i, i + 1) for i in range(n - 1)]),
        ),
        (
            "C5",
            cycle_string(n),
        ),
        (
            "K5",
            graph_string(n, [(i, j) for i in range(n) for j in range(i + 1, n)]),
        ),
        (
            "P5 + cuerda",
            graph_string(
                n,
                [(i, i + 1) for i in range(n - 1)] + [(0, 2)],
            ),
        ),
        (
            "estrella K1,4",
            graph_string(n, [(0, i) for i in range(1, n)]),
        ),
    ]


def example_table():
    n = 5
    examples = example_graphs()
    print("| grafo | aristas | camino hamiltoniano | isomorfo exacto a P5 |")
    print("|---|---:|---|---|")
    for name, x in examples:
        order_brute = has_hamiltonian_path_bruteforce(n, x)
        order_dp = has_hamiltonian_path_dp(n, x)
        exact = exact_path_isomorphism(n, x)
        if (order_brute is None) != (order_dp is None):
            raise AssertionError("Discrepancia fuerza bruta / DP en %s." % name)
        print(
            "| %s | %d | %s | %s |"
            % (
                name,
                x.count("1"),
                "sí" if order_brute is not None else "no",
                "sí" if exact else "no",
            )
        )


def symmetry_table():
    n = 5
    print("\n| grafo | tamaño de Aut(G) | órbitas de vértices |")
    print("|---|---:|---:|")
    for name, x in example_graphs():
        automorphisms = graph_automorphisms_bruteforce(n, x)
        representatives = vertex_orbit_representatives(n, automorphisms)
        order = has_hamiltonian_path_symmetry_reduced(n, x, automorphisms)
        expected = has_hamiltonian_path_bruteforce(n, x)
        if (order is None) != (expected is None):
            raise AssertionError("La reducción por simetría falló en %s." % name)
        print(
            "| %s | %d | %d |"
            % (name, len(automorphisms), len(representatives))
        )


def exhaustive_check(n):
    """Compara fuerza bruta, DP y el test exacto en todos los grafos de n vértices."""
    total = 1 << (n * (n - 1) // 2)
    mismatches = 0
    exact_but_not_hp = 0
    hp_but_not_exact = 0
    for mask in range(total):
        x = "".join(
            "1" if (mask >> bit) & 1 else "0"
            for bit in range(n * (n - 1) // 2)
        )
        brute = has_hamiltonian_path_bruteforce(n, x)
        dp = has_hamiltonian_path_dp(n, x)
        exact = exact_path_isomorphism(n, x) if n <= babai.MAX_N else None
        if (brute is None) != (dp is None):
            mismatches += 1
        if exact and brute is None:
            exact_but_not_hp += 1
        if exact is False and brute is not None:
            hp_but_not_exact += 1
    print(
        "n=%d: %d grafos, discrepancias fuerza bruta/DP=%d, "
        "exacto sin camino=%d, camino sin exacto=%d"
        % (n, total, mismatches, exact_but_not_hp, hp_but_not_exact)
    )


def benchmark(n_values):
    rng = random.Random(0)
    print("\n| n | fuerza bruta (s) | DP (s) | permutaciones | estados DP |")
    print("|---:|---:|---:|---:|---:|")
    for n in n_values:
        p = 0.35
        edges = [
            (i, j)
            for i in range(n)
            for j in range(i + 1, n)
            if rng.random() < p
        ]
        x = graph_string(n, edges)

        started = time.perf_counter()
        has_hamiltonian_path_bruteforce(n, x)
        brute_time = time.perf_counter() - started

        started = time.perf_counter()
        has_hamiltonian_path_dp(n, x)
        dp_time = time.perf_counter() - started

        print(
            "| %d | %.4f | %.4f | %d | %d |"
            % (
                n,
                brute_time,
                dp_time,
                __import__("math").factorial(n),
                n * (1 << n),
            )
        )


def main():
    example_table()
    symmetry_table()
    symmetry_dp_table()
    exhaustive_check(4)
    exhaustive_check(5)
    canonical_experiment(5)
    benchmark([8, 9, 10])


if __name__ == "__main__":
    main()
