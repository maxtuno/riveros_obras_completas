"""
HAMPATH algebraico: conteo por inclusión-exclusión y banco de pruebas.

La identidad usada es:

    #caminos hamiltonianos orientados
      = Σ_{S ⊆ V} (-1)^{n-|S|} · suma de entradas de A[S]^{n-1}.

Un camino de longitud n-1 que visita todos los vértices es exactamente un
camino hamiltoniano. La inclusión-exclusión elimina los caminos que olvidan
algún vértice.

Esto es una formulación algebraica clásica, no una mejora de complejidad:
cuesta O(2^n n^3), peor que la DP O(n^2 2^n). Sirve como banco de pruebas para
las técnicas de los manuscritos de 2026 (sumas de productos, tensor networks,
interpolación, reescritura de aristas).
"""

import itertools
import time

from hamiltonian_matrix import graph_string, path_string, cycle_string, has_hamiltonian_path_dp


def matrix_multiply(left, right):
    n = len(left)
    result = [[0] * n for _ in range(n)]
    for i in range(n):
        for k in range(n):
            value = left[i][k]
            if value:
                for j in range(n):
                    result[i][j] += value * right[k][j]
    return result


def adjacency_matrix(n, x):
    pairs = list(itertools.combinations(range(n), 2))
    matrix = [[0] * n for _ in range(n)]
    for index, (first, second) in enumerate(pairs):
        matrix[first][second] = matrix[second][first] = int(x[index])
    return matrix


def count_paths_inclusion_exclusion(n, x):
    """Cuenta caminos hamiltonianos orientados por inclusión-exclusión."""
    if n == 0:
        return 1
    adjacency = adjacency_matrix(n, x)
    total = 0
    for mask in range(1 << n):
        vertices = [vertex for vertex in range(n) if (mask >> vertex) & 1]
        k = len(vertices)
        if k == 0:
            continue
        block = [[adjacency[u][v] for v in vertices] for u in vertices]
        power = [[1 if i == j else 0 for j in range(k)] for i in range(k)]
        for _ in range(n - 1):
            power = matrix_multiply(power, block)
        walks = sum(sum(row) for row in power)
        if (n - k) % 2:
            total -= walks
        else:
            total += walks
    return total


def count_paths_dp(n, x):
    """Cuenta caminos hamiltonianos orientados con Held--Karp."""
    if n == 0:
        return 1
    pairs = list(itertools.combinations(range(n), 2))
    index = {pair: position for position, pair in enumerate(pairs)}
    full = (1 << n) - 1
    dp = [[0] * n for _ in range(1 << n)]
    for vertex in range(n):
        dp[1 << vertex][vertex] = 1
    for mask in range(1 << n):
        for last in range(n):
            if not dp[mask][last]:
                continue
            for nxt in range(n):
                if mask & (1 << nxt):
                    continue
                first, second = (last, nxt) if last < nxt else (nxt, last)
                if x[index[(first, second)]] == "1":
                    dp[mask | (1 << nxt)][nxt] += dp[mask][last]
    return sum(dp[full][vertex] for vertex in range(n))


def examples():
    n = 5
    return [
        ("P5", graph_string(n, [(i, i + 1) for i in range(n - 1)])),
        ("C5", graph_string(n, [(i, (i + 1) % n) for i in range(n)])),
        ("K5", graph_string(n, [(i, j) for i in range(n) for j in range(i + 1, n)])),
        ("estrella", graph_string(n, [(0, i) for i in range(1, n)])),
    ]


def main():
    print("| grafo | caminos (inclusión-exclusión) | caminos (DP) |")
    print("|---|---:|---:|")
    for name, x in examples():
        ie = count_paths_inclusion_exclusion(5, x)
        dp = count_paths_dp(5, x)
        print("| %s | %d | %d |" % (name, ie, dp))

    print("\n| grafo | n | inclusión-exclusión (s) | DP (s) | caminos |")
    print("|---|---:|---:|---:|---:|")
    for n in [6, 7, 8]:
        complete = graph_string(
            n, [(i, j) for i in range(n) for j in range(i + 1, n)]
        )
        cases = [
            ("P%d" % n, path_string(n)),
            ("C%d" % n, cycle_string(n)),
            ("K%d" % n, complete),
        ]
        for name, x in cases:
            started = time.perf_counter()
            ie = count_paths_inclusion_exclusion(n, x)
            ie_time = time.perf_counter() - started
            started = time.perf_counter()
            dp = count_paths_dp(n, x)
            dp_time = time.perf_counter() - started
            if ie != dp:
                raise AssertionError("Discrepancia en %s: %d vs %d" % (name, ie, dp))
            print(
                "| %s | %d | %.4f | %.4f | %d |"
                % (name, n, ie_time, dp_time, ie)
            )


if __name__ == "__main__":
    main()
