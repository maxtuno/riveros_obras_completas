"""
Descomposición por bloques del tensor completo de HAMPATH.

    H_G(v_1,...,v_n) = D_n(v_1,...,v_n) * prod_{i=1}^{n-1} A[v_i,v_{i+1}].

Para el corte k | n-k, las filas se agrupan por el conjunto S de los primeros k
vértices. El bloque correspondiente es

    B_S = P_S * A[S, V\\S] * Q_S,

donde P_S registra los caminos de G[S] por su extremo final y Q_S los del
complemento por su extremo inicial. Si E_S y T_S son los extremos alcanzables,

    rank(B_S) = rank(A[E_S, T_S]),

y el rango del flattening completo es la suma de los rangos de los bloques.
"""

import itertools
import random

from hamiltonian_matrix import graph_string, path_string, cycle_string
from hampath_full_rank import hamiltonian_path_count, hampath_flattening
from hampath_rank import rank_mod


def edge_set(n, x):
    pairs = list(itertools.combinations(range(n), 2))
    return {pair for index, pair in enumerate(pairs) if x[index] == "1"}


def adjacency(n, edges):
    matrix = [[0] * n for _ in range(n)]
    for u, v in edges:
        matrix[u][v] = matrix[v][u] = 1
    return matrix


def path_profile(vertices, matrix):
    """Cuenta los caminos que cubren `vertices` y terminan o empiezan en cada
    vértice. Los caminos son orientados."""
    vertices = tuple(vertices)
    ends = {v: 0 for v in vertices}
    starts = {v: 0 for v in vertices}
    for order in itertools.permutations(vertices):
        if all(matrix[order[i]][order[i + 1]] for i in range(len(order) - 1)):
            ends[order[-1]] += 1
            starts[order[0]] += 1
    return ends, starts


def path_matrix(vertices, matrix, at_start=False):
    """Filas: órdenes de `vertices`. Columnas: vértices. La entrada vale uno
    si el orden es un camino y empieza (o termina) en la columna."""
    vertices = tuple(vertices)
    index = {v: i for i, v in enumerate(vertices)}
    rows = []
    for order in itertools.permutations(vertices):
        row = [0] * len(vertices)
        if all(matrix[order[i]][order[i + 1]] for i in range(len(order) - 1)):
            row[index[order[0] if at_start else order[-1]]] = 1
        rows.append(row)
    return rows


def transpose(matrix):
    return [list(row) for row in zip(*matrix)]


def product(left, right):
    return [
        [
            sum(left[i][t] * right[t][j] for t in range(len(right)))
            for j in range(len(right[0]))
        ]
        for i in range(len(left))
    ]


def block_from_profiles(n, matrix, subset):
    subset = tuple(sorted(subset))
    complement = tuple(v for v in range(n) if v not in subset)
    ends, _ = path_profile(subset, matrix)
    _, starts = path_profile(complement, matrix)
    P = path_matrix(subset, matrix)
    Q = transpose(path_matrix(complement, matrix, at_start=True))
    cut = [[matrix[u][v] for v in complement] for u in subset]
    return product(product(P, cut), Q), ends, starts


def direct_block(full, row_index, col_index, subset, complement):
    return [
        [full[row_index[order]][col_index[rest]] for rest in itertools.permutations(complement)]
        for order in itertools.permutations(subset)
    ]


def verify(n, x, k):
    matrix = adjacency(n, edge_set(n, x))
    full = hampath_flattening(n, x, k)
    rows = list(itertools.product(range(n), repeat=k))
    cols = list(itertools.product(range(n), repeat=n - k))
    row_index = {row: i for i, row in enumerate(rows)}
    col_index = {col: j for j, col in enumerate(cols)}

    total_rank = 0
    max_block = 0
    count = 0
    for subset in itertools.combinations(range(n), k):
        complement = tuple(v for v in range(n) if v not in subset)
        block, ends, starts = block_from_profiles(n, matrix, subset)
        direct = direct_block(full, row_index, col_index, subset, complement)
        assert block == direct, "el bloque no factoriza"

        rank = rank_mod(direct)
        possible_ends = [u for u in subset if ends[u]]
        possible_starts = [v for v in complement if starts[v]]
        restricted = [
            [matrix[u][v] for v in possible_starts] for u in possible_ends
        ]
        assert rank == rank_mod(restricted), "rango distinto del esperado"

        total_rank += rank
        max_block = max(max_block, rank)
        count += sum(
            ends[u] * matrix[u][v] * starts[v]
            for u in subset for v in complement
        )

    assert rank_mod(full) == total_rank, "el rango total no es la suma"
    assert count == hamiltonian_path_count(n, x), "el conteo por bloques falla"
    return total_rank, max_block


def random_graph(n, p, rng):
    edges = [
        pair for pair in itertools.combinations(range(n), 2)
        if rng.random() < p
    ]
    return graph_string(n, edges)


def main():
    n = 6
    complete = graph_string(
        n, [(i, j) for i in range(n) for j in range(i + 1, n)]
    )
    prism = [
        (0, 1), (1, 2), (2, 0),
        (3, 4), (4, 5), (5, 3),
        (0, 3), (1, 4), (2, 5),
    ]
    k33 = [(i, j) for i in range(3) for j in range(3, 6)]
    cases = [
        ("P6", path_string(n)),
        ("C6", cycle_string(n)),
        ("K6", complete),
        ("prisma", graph_string(n, prism)),
        ("K3,3", graph_string(n, k33)),
    ]
    print("| grafo | caminos | max rank bloque | suma rangos | rango H | C(6,3) |")
    print("|---|---:|---:|---:|---:|---:|")
    for name, x in cases:
        total, maximum = verify(n, x, 3)
        print(
            "| %s | %d | %d | %d | %d | 20 |"
            % (name, hamiltonian_path_count(n, x), maximum, total, total)
        )

    rng = random.Random(20261030)
    for size, count, cuts in [(4, 64, range(1, 4)), (5, 128, range(1, 5)),
                              (6, 32, [3])]:
        for index in range(count):
            if size == 4:
                edges = [
                    pair for bit, pair in enumerate(itertools.combinations(range(size), 2))
                    if (index >> bit) & 1
                ]
                x = graph_string(size, edges)
            else:
                x = random_graph(size, 0.5, rng)
            for cut in cuts:
                verify(size, x, cut)
        print("verificado: n=%d, %d grafos, cortes %s" % (size, count, list(cuts)))


if __name__ == "__main__":
    main()
