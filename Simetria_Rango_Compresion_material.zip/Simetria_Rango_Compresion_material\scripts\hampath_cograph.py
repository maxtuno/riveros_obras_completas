"""
HAMPATH en cografos.

Un cografo se construye desde vértices con dos operaciones:
  - unión disjunta;
  - join (todas las aristas entre las dos partes).

Sea p(G) el mínimo número de caminos disjuntos que cubren todos los vértices.
Para cografos:

  p(hoja) = 1
  p(G1 ∪ G2) = p(G1) + p(G2)
  p(G1 ∨ G2) = max(1, distancia entre [p1,n1] y [p2,n2])

HAMPATH ⇔ p(G) = 1.

La recurrencia del join se justifica alternando caminos de ambas partes: si
p1 ≥ p2, los p2 caminos de G2 pueden separar p2+1 grupos de caminos de G1 y
fusionarlos; quedan p1-p2 caminos.
"""

import random
from functools import lru_cache

from hamiltonian_matrix import graph_string, has_edge, has_hamiltonian_path_dp


def leaf(vertex):
    return ("leaf", vertex)


def union(left, right):
    return ("union", left, right)


def join(left, right):
    return ("join", left, right)


@lru_cache(maxsize=None)
def path_cover_interval(expression):
    """
    Devuelve (p_min, n). Los números de cubierta alcanzables son [p_min, n]:
    desde una cubierta mínima se pueden quitar aristas y partir caminos.
    """
    kind = expression[0]
    if kind == "leaf":
        return 1, 1
    p_left, n_left = path_cover_interval(expression[1])
    p_right, n_right = path_cover_interval(expression[2])
    if kind == "union":
        return p_left + p_right, n_left + n_right
    # join: elegir p1 en [p_left,n_left], p2 en [p_right,n_right].
    # El mínimo de |p1-p2| es la distancia entre los intervalos.
    if p_left > n_right:
        gap = p_left - n_right
    elif p_right > n_left:
        gap = p_right - n_left
    else:
        gap = 0
    return max(1, gap), n_left + n_right


def path_cover_number(expression):
    return path_cover_interval(expression)[0]


def merge_cover_lists(first, second):
    """Fusiona dos cubiertas con todas las aristas cruzadas disponibles."""
    if len(first) >= len(second):
        longer, shorter = first, second
    else:
        longer, shorter = second, first
    current = list(longer[0])
    for index, path in enumerate(shorter):
        current.extend(path)
        if index + 1 < len(longer):
            current.extend(longer[index + 1])
    merged = [tuple(current)]
    merged.extend(tuple(path) for path in longer[len(shorter) + 1:])
    return merged


def split_cover_to(paths, desired):
    """Parte caminos hasta alcanzar el número deseado de caminos."""
    paths = [tuple(path) for path in paths]
    while len(paths) < desired:
        index = next((i for i, path in enumerate(paths) if len(path) >= 2), None)
        if index is None:
            return None
        path = paths.pop(index)
        middle = max(1, len(path) // 2)
        paths.append(path[:middle])
        paths.append(path[middle:])
    return paths


def covers(expression, desired):
    """Cubierta con exactamente `desired` caminos, o None."""
    p_min, n = path_cover_interval(expression)
    if desired < p_min or desired > n:
        return None
    kind = expression[0]
    if kind == "leaf":
        return [[expression[1]]] if desired == 1 else None
    p_left, n_left = path_cover_interval(expression[1])
    p_right, n_right = path_cover_interval(expression[2])
    if kind == "union":
        low = max(p_left, desired - n_right)
        high = min(n_left, desired - p_right)
        if low > high:
            return None
        left_count = low
        right_count = desired - left_count
        left = covers(expression[1], left_count)
        right = covers(expression[2], right_count)
        if left is None or right is None:
            return None
        return left + right
    if p_left > n_right:
        left_count, right_count = p_left, n_right
    elif p_right > n_left:
        left_count, right_count = n_left, p_right
    else:
        common = max(p_left, p_right)
        left_count = right_count = common
    left = covers(expression[1], left_count)
    right = covers(expression[2], right_count)
    if left is None or right is None:
        return None
    merged = merge_cover_lists(left, right)
    return split_cover_to(merged, desired)


def path_from_expression(expression):
    cover = covers(expression, 1)
    return cover[0] if cover else None


def graph_from_expression(expression):
    if expression[0] == "leaf":
        return {expression[1]}, set()
    left_vertices, left_edges = graph_from_expression(expression[1])
    right_vertices, right_edges = graph_from_expression(expression[2])
    vertices = left_vertices | right_vertices
    edges = set(left_edges) | set(right_edges)
    if expression[0] == "join":
        edges |= {(u, v) for u in left_vertices for v in right_vertices}
    return vertices, edges


def random_cograph(n, rng):
    if n == 1:
        return leaf(rng.randrange(10**9))
    split = rng.randint(1, n - 1)
    left = random_cograph(split, rng)
    right = random_cograph(n - split, rng)
    return (rng.choice(("union", "join")), left, right)


def relabel(expression):
    """Reasigna hojas a 0..n-1 en orden de aparición."""
    counter = [0]

    def visit(node):
        if node[0] == "leaf":
            value = counter[0]
            counter[0] += 1
            return leaf(value)
        return (node[0], visit(node[1]), visit(node[2]))

    return visit(expression), counter[0]


def main():
    rng = random.Random(0)
    checks = 0
    reconstructed = 0
    for n in range(2, 9):
        for _ in range(100):
            expression, size = relabel(random_cograph(n, rng))
            vertices, edges = graph_from_expression(expression)
            assert len(vertices) == n
            x = graph_string(n, sorted(edges))
            predicted = path_cover_number(expression) == 1
            actual = has_hamiltonian_path_dp(n, x) is not None
            if predicted != actual:
                raise AssertionError(
                    "Discrepancia n=%d, p=%d: %s vs %s"
                    % (n, path_cover_number(expression), predicted, actual)
                )
            if predicted:
                path = path_from_expression(expression)
                if path is None or len(path) != n or set(path) != set(range(n)):
                    raise AssertionError(
                        "Camino mal reconstruido n=%d: %s" % (n, path)
                    )
                if any(not has_edge(x, n, a, b) for a, b in zip(path, path[1:])):
                    raise AssertionError(
                        "Arista inválida en el camino n=%d: %s" % (n, path)
                    )
                reconstructed += 1
            checks += 1
    print("Cografos aleatorios verificados:", checks)
    print("Caminos reconstruidos y validados:", reconstructed)


if __name__ == "__main__":
    main()
