"""
Descomposiciones del factor all-different en HAMPATH: coste asintótico.

Tres representaciones:
  1. factores de desigualdad por pares: ancho n-1, coste n^n;
  2. inclusión-exclusión sobre subconjuntos: 2^n términos de ancho 1,
     coste 2^n * n^3;
  3. estado de subconjunto (Held--Karp): 2^n estados de máscara,
     coste n^2 * 2^n.

El factor all-different no desaparece: se paga en ancho, en número de términos
o en tamaño del estado. La pregunta es si una descomposición más fina
(edge-rewriting/interpolación) puede reducir ese exponente.
"""

import math


def log2_direct(n):
    return n * math.log2(n)


def log2_inclusion_exclusion(n):
    return n + 3 * math.log2(n)


def log2_subset_dp(n):
    return math.log2(n) + n - 1


def main():
    print("| n | log2 directo (n^n) | log2 IE (2^n n^3) | log2 DP (n 2^n) |")
    print("|---:|---:|---:|---:|")
    for n in [4, 6, 8, 10, 12, 16, 20]:
        print(
            "| %d | %.2f | %.2f | %.2f |"
            % (
                n,
                log2_direct(n),
                log2_inclusion_exclusion(n),
                log2_subset_dp(n),
            )
        )

    print(
        "\nEl factor all-different se paga en ancho (n-1), en 2^n términos "
        "o en 2^n estados de subconjunto. La DP es la mejor de las tres."
    )


if __name__ == "__main__":
    main()
