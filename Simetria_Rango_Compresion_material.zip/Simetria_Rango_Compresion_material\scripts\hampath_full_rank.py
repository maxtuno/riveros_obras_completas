"""
Rango del tensor completo de HAMPATH.

H(v1,...,vn) = 1 si el orden es un camino hamiltoniano de G, 0 si no.
Se calcula el rango de un flattening k | n-k sobre un cuerpo finito.

Compara con el rango del all-different C(n,k). Si el rango de H es menor,
la estructura de G reduce el tensor; si es igual, el cuello es all-different.
"""

import itertools

from hamiltonian_matrix import (
    graph_string,
    path_string,
    cycle_string,
    has_edge,
)
from hampath_rank import rank_mod


def hamiltonian_path_count(n, x):
    count = 0
    for order in itertools.permutations(range(n)):
        if all(has_edge(x, n, order[i], order[i + 1]) for i in range(n - 1)):
            count += 1
    return count


def hampath_flattening(n, x, k):
    rows = list(itertools.product(range(n), repeat=k))
    cols = list(itertools.product(range(n), repeat=n - k))
    row_index = {row: i for i, row in enumerate(rows)}
    col_index = {col: j for j, col in enumerate(cols)}
    matrix = [[0] * len(cols) for _ in range(len(rows))]
    for order in itertools.permutations(range(n)):
        if not all(has_edge(x, n, order[i], order[i + 1]) for i in range(n - 1)):
            continue
        matrix[row_index[order[:k]]][col_index[order[k:]]] = 1
    return matrix


def main():
    n = 6
    complete = graph_string(
        n, [(i, j) for i in range(n) for j in range(i + 1, n)]
    )
    prism_edges = [
        (0, 1), (1, 2), (2, 0),
        (3, 4), (4, 5), (5, 3),
        (0, 3), (1, 4), (2, 5),
    ]
    k33_edges = [
        (i, j) for i in range(3) for j in range(3, 6)
    ]
    cases = [
        ("P6", path_string(n)),
        ("C6", cycle_string(n)),
        ("K6", complete),
        ("prisma", graph_string(n, prism_edges)),
        ("K3,3", graph_string(n, k33_edges)),
    ]
    print("| grafo | caminos | k | rango H | C(n,k) |")
    print("|---|---:|---:|---:|---:|")
    for name, x in cases:
        count = hamiltonian_path_count(n, x)
        for k in [2, 3]:
            rank = rank_mod(hampath_flattening(n, x, k))
            choose = len(list(itertools.combinations(range(n), k)))
            print("| %s | %d | %d | %d | %d |" % (name, count, k, rank, choose))


if __name__ == "__main__":
    main()
