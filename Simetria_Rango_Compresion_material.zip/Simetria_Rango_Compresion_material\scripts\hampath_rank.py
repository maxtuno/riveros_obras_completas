"""
Rango del tensor all-different y su relación con la DP.

T(v1,...,vn) = 1 si v1,...,vn son todos distintos, 0 si no.
Se calcula el rango de un flattening (primeras k variables vs. el resto)
sobre un cuerpo finito grande. Un rango alto impide una descomposición
tensor-train de bond pequeño.
"""

import itertools

MOD = 1_000_000_007


def all_different_tensor(n):
    for values in itertools.product(range(n), repeat=n):
        yield values, 1 if len(set(values)) == n else 0


def flattening_matrix(n, k):
    rows = list(itertools.product(range(n), repeat=k))
    cols = list(itertools.product(range(n), repeat=n - k))
    row_index = {row: i for i, row in enumerate(rows)}
    col_index = {col: j for j, col in enumerate(cols)}
    matrix = [[0] * len(cols) for _ in range(len(rows))]
    for values, entry in all_different_tensor(n):
        if not entry:
            continue
        matrix[row_index[values[:k]]][col_index[values[k:]]] = 1
    return matrix


def rank_mod(matrix, mod=MOD):
    if not matrix:
        return 0
    a = [row[:] for row in matrix]
    rows = len(a)
    cols = len(a[0])
    rank = 0
    for col in range(cols):
        pivot = None
        for row in range(rank, rows):
            if a[row][col] % mod:
                pivot = row
                break
        if pivot is None:
            continue
        a[rank], a[pivot] = a[pivot], a[rank]
        inv = pow(a[rank][col], mod - 2, mod)
        a[rank] = [(value * inv) % mod for value in a[rank]]
        for row in range(rows):
            if row == rank:
                continue
            factor = a[row][col] % mod
            if factor:
                a[row] = [
                    (a[row][j] - factor * a[rank][j]) % mod
                    for j in range(cols)
                ]
        rank += 1
        if rank == rows:
            break
    return rank


def main():
    print("| n | k | rango del flattening | C(n,k) |")
    print("|---:|---:|---:|---:|")
    for n in [4, 5, 6]:
        for k in range(1, n):
            matrix = flattening_matrix(n, k)
            rank = rank_mod(matrix)
            choose = len(list(itertools.combinations(range(n), k)))
            print("| %d | %d | %d | %d |" % (n, k, rank, choose))


if __name__ == "__main__":
    main()
