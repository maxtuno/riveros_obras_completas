"""
Cociente de los caminos hamiltonianos por Aut(G).

Mide cuántos órdenes de camino hay y cuántas órbitas quedan bajo las
simetrías del grafo. Es la parte de la simetría all-different que sobrevive
cuando se impone la adyacencia de G.
"""

import itertools

from hamiltonian_matrix import (
    graph_string,
    path_string,
    cycle_string,
    has_edge,
    graph_automorphisms_bruteforce,
)


def hamiltonian_path_orders(n, x):
    orders = []
    for order in itertools.permutations(range(n)):
        if all(has_edge(x, n, order[i], order[i + 1]) for i in range(n - 1)):
            orders.append(order)
    return orders


def orbit_count(n, orders, automorphisms):
    remaining = set(orders)
    orbits = 0
    while remaining:
        order = next(iter(remaining))
        orbit = {order}
        changed = True
        while changed:
            changed = False
            for image in list(orbit):
                for permutation in automorphisms:
                    composed = tuple(permutation[vertex] for vertex in image)
                    if composed in remaining and composed not in orbit:
                        orbit.add(composed)
                        changed = True
        remaining -= orbit
        orbits += 1
    return orbits


def main():
    n = 6
    complete = graph_string(
        n, [(i, j) for i in range(n) for j in range(i + 1, n)]
    )
    cases = [
        ("P6", path_string(n)),
        ("C6", cycle_string(n)),
        ("K6", complete),
        (
            "P6 + cuerda",
            graph_string(
                n,
                [(i, i + 1) for i in range(n - 1)] + [(0, 2)],
            ),
        ),
        (
            "P6 + cuerdas (rígido)",
            graph_string(
                n,
                [(i, i + 1) for i in range(n - 1)] + [(0, 4), (1, 4)],
            ),
        ),
    ]
    print("| grafo | |Aut(G)| | caminos | órbitas de caminos | reducción |")
    print("|---|---:|---:|---:|---:|")
    for name, x in cases:
        automorphisms = graph_automorphisms_bruteforce(n, x)
        orders = hamiltonian_path_orders(n, x)
        orbits = orbit_count(n, orders, automorphisms)
        print(
            "| %s | %d | %d | %d | %.1f |"
            % (
                name,
                len(automorphisms),
                len(orders),
                orbits,
                len(orders) / orbits if orbits else 0,
            )
        )


if __name__ == "__main__":
    main()
