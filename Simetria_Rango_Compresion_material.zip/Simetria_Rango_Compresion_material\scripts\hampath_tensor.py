"""
Ancho de contracción del tensor network de HAMPATH.

Formulación directa:
  - variables de posición v1,...,vn, cada una con dominio [n];
  - factores de adyacencia A(vi,vi+1);
  - factores de desigualdad [vi != vj] para todo i < j.

El grafo primal es completo por las desigualdades. Se mide el ancho inducido
de la eliminación de variables y se compara con el estado 2^n de la DP.

No se implementa todavía la reescritura de aristas de Anthropic; este módulo
mide el punto de partida y muestra qué factor hay que descomponer.
"""

import itertools
import math


def induced_width(n, factors, order):
    """Ancho inducido de eliminar variables en el orden dado."""
    active_factors = [set(scope) for scope in factors]
    width = 0
    widths = []
    for variable in order:
        containing = [factor for factor in active_factors if variable in factor]
        neighbors = set()
        for factor in containing:
            neighbors |= factor
        neighbors.discard(variable)
        widths.append(len(neighbors))
        width = max(width, len(neighbors))
        active_factors = [
            factor - {variable} for factor in active_factors
        ]
        active_factors = [factor for factor in active_factors if factor]
        if len(neighbors) > 1:
            active_factors.append(set(neighbors))
    return width, widths


def natural_factors(n):
    factors = []
    for i in range(n - 1):
        factors.append({i, i + 1})
    for i in range(n):
        for j in range(i + 1, n):
            factors.append({i, j})
    return factors


def path_only_factors(n):
    return [{i, i + 1} for i in range(n - 1)]


def main():
    print("| n | ancho natural | log2(n^n) | log2(n·2^n) DP | ancho sin all-different |")
    print("|---:|---:|---:|---:|---:|")
    for n in range(3, 13):
        order = list(range(n))
        width, _ = induced_width(n, natural_factors(n), order)
        width_path, _ = induced_width(n, path_only_factors(n), order)
        print(
            "| %d | %d | %.2f | %.2f | %d |"
            % (
                n,
                width,
                n * math.log2(n),
                math.log2(n) + n,
                width_path,
            )
        )

    print(
        "\nEl tensor network directo paga n^n entradas en el mayor factor; "
        "la DP paga n·2^n estados. El factor de desigualdades es el que "
        "completa el grafo y produce ancho n-1."
    )


if __name__ == "__main__":
    main()
