"""
HAMPATH -> GI: qué reducción existe y cuál no.

La reducción exacta y directa es una reducción de Turing con muchos objetivos:

    G tiene camino hamiltoniano
      ⇔ existe B en L_n tal que G es isomorfo a B,

donde L_n es el conjunto de grafos con la superdiagonal (1,2), (2,3), ...,
(n-1,n) llena; las demás aristas son libres.

L_n tiene 2^(C(n,2) - (n-1)) elementos. Enumerarlos y consultar GI para cada
uno es correcto, pero exponencial. No se conoce una reducción polinómica a un
único GI; encontrarla haría GI NP-hard.

Este módulo mide el tamaño de L_n, verifica la equivalencia en n pequeño y
compara con el caso exacto (m = n-1).
"""

import itertools
import random

import babai
from hamiltonian_matrix import (
    edge_index,
    graph_string,
    has_hamiltonian_path_dp,
    canonical_form,
    pairs,
)


def superdiagonal_targets(n):
    """Todos los grafos con aristas (i,i+1); el resto es libre."""
    required = {(i, i + 1) for i in range(n - 1)}
    optional = [pair for pair in pairs(n) if pair not in required]
    for mask in range(1 << len(optional)):
        edges = list(required)
        for bit, pair in enumerate(optional):
            if (mask >> bit) & 1:
                edges.append(pair)
        yield graph_string(n, edges)


def target_count(n):
    return 1 << (n * (n - 1) // 2 - (n - 1))


def belongs_to_targets_by_gi(n, x, targets):
    """Consulta GI contra cada objetivo; devuelve (sí/no, consultas)."""
    for target in targets:
        if babai.babai_graph_isomorphism(n, x, target)[0]:
            return True, 1
    return False, len(targets)


def verify_small_with_gi(n):
    targets = list(superdiagonal_targets(n))
    total = 1 << (n * (n - 1) // 2)
    mismatches = 0
    queries = 0
    for mask in range(total):
        x = "".join(
            "1" if (mask >> bit) & 1 else "0"
            for bit in range(n * (n - 1) // 2)
        )
        expected = has_hamiltonian_path_dp(n, x) is not None
        actual, used = belongs_to_targets_by_gi(n, x, targets)
        queries += used
        if expected != actual:
            mismatches += 1
    print(
        "n=%d: objetivos=%d, grafos=%d, consultas GI=%d, discrepancias=%d"
        % (n, len(targets), total, queries, mismatches)
    )


def verify_small_with_canonical(n):
    """
    Misma reducción, usando formas canónicas en vez de una consulta GI por
    objetivo. Sigue siendo exponencial por el número de objetivos.
    """
    target_forms = {canonical_form(n, target)[0] for target in superdiagonal_targets(n)}
    total = 1 << (n * (n - 1) // 2)
    mismatches = 0
    for mask in range(total):
        x = "".join(
            "1" if (mask >> bit) & 1 else "0"
            for bit in range(n * (n - 1) // 2)
        )
        expected = has_hamiltonian_path_dp(n, x) is not None
        actual = canonical_form(n, x)[0] in target_forms
        if expected != actual:
            mismatches += 1
    print(
        "n=%d: clases de objetivos=%d, grafos=%d, discrepancias=%d"
        % (n, len(target_forms), total, mismatches)
    )



def degree_sequence(n, x):
    index = edge_index(n)
    degrees = [0] * n
    for first, second in pairs(n):
        if x[index[(first, second)]] == "1":
            degrees[first] += 1
            degrees[second] += 1
    return tuple(sorted(degrees))


def invariant_counts(n, x):
    edges = x.count("1")
    degrees = degree_sequence(n, x)
    total = 0
    edge_candidates = 0
    degree_candidates = 0
    for target in superdiagonal_targets(n):
        total += 1
        if target.count("1") != edges:
            continue
        edge_candidates += 1
        if degree_sequence(n, target) == degrees:
            degree_candidates += 1
    return total, edge_candidates, degree_candidates


def invariant_table():
    n = 5
    examples = [
        ("P5", graph_string(n, [(i, i + 1) for i in range(n - 1)])),
        ("C5", graph_string(n, [(i, (i + 1) % n) for i in range(n)])),
        ("K5", graph_string(n, [(i, j) for i in range(n) for j in range(i + 1, n)])),
        ("P5 + cuerda", graph_string(n, [(i, i + 1) for i in range(n - 1)] + [(0, 2)])),
    ]
    rng = random.Random(1)
    for name, edge_count in [("aleatoria(n=6)", 8), ("aleatoria(n=7)", 12)]:
        m = 6 if name.endswith("6)") else 7
        edges = []
        while len(edges) < edge_count:
            a = rng.randrange(m)
            b = rng.randrange(m)
            if a == b:
                continue
            if a > b:
                a, b = b, a
            if (a, b) not in edges:
                edges.append((a, b))
        examples.append((name, graph_string(m, edges)))

    print("\n| grafo | n | m | objetivos totales | filtro aristas | filtro grados |")
    print("|---|---:|---:|---:|---:|---:|")
    for name, x in examples:
        n = int(name.split("n=")[-1].rstrip(")")) if "n=" in name else 5
        total, edge_candidates, degree_candidates = invariant_counts(n, x)
        print(
            "| %s | %d | %d | %d | %d | %d |"
            % (name, n, x.count("1"), total, edge_candidates, degree_candidates)
        )


def sparse_exact_case(n, x):
    """
    Caso polinómico especial: si el grafo tiene exactamente n-1 aristas,
    camino hamiltoniano ⇔ es isomorfo a P_n. Una sola consulta GI.
    """
    if x.count("1") != n - 1:
        return None
    path = graph_string(n, [(i, i + 1) for i in range(n - 1)])
    return babai.babai_graph_isomorphism(n, x, path)[0]


def main():
    print("La reducción directa enumera L_n:")
    for n in [4, 5, 6, 10]:
        print("  n=%d: %d objetivos" % (n, target_count(n)))

    verify_small_with_gi(4)
    verify_small_with_canonical(5)
    invariant_table()

    n = 5
    x = graph_string(n, [(i, i + 1) for i in range(n - 1)])
    print(
        "P5: tiene %d aristas, isomorfo exacto a P5 = %s"
        % (x.count("1"), sparse_exact_case(n, x))
    )


if __name__ == "__main__":
    main()
