"""
Codificaciones lineales y el límite de O(n) variables para HAMPATH.

- Set Splitting: una variable por elemento, dos cláusulas por conjunto.
- Coloración: n·k variables, O(nk² + mk) cláusulas; lineal para k fijo.
- HAMPATH: n! caminos exigen al menos log2(n!) = Θ(n log n) variables si cada
  camino necesita al menos un modelo. Una codificación O(n) de variables es
  imposible; O(n) de cláusulas queda abierta.
"""

import itertools
import math
import random


def set_splitting_cnf(elements, sets):
    """Cada conjunto debe tener al menos un 0 y al menos un 1."""
    clauses = []
    for group in sets:
        clauses.append(list(group))
        clauses.append([-element for element in group])
    return elements, clauses


def clause_satisfied(clause, assignment):
    for literal in clause:
        value = assignment[abs(literal) - 1]
        if (literal > 0 and value == 1) or (literal < 0 and value == 0):
            return True
    return False


def satisfies(n, clauses, assignment):
    return all(clause_satisfied(clause, assignment) for clause in clauses)


def set_splitting_bruteforce(elements, sets, assignment):
    return all(
        len({assignment[element - 1] for element in group}) == 2
        for group in sets
    )


def coloring_cnf(n, edges, colors):
    """Coloración propia con `colors` colores; variables 1..n*colors."""
    def var(vertex, color):
        return vertex * colors + color + 1

    clauses = []
    for vertex in range(n):
        clauses.append([var(vertex, color) for color in range(colors)])
        for first in range(colors):
            for second in range(first + 1, colors):
                clauses.append([-var(vertex, first), -var(vertex, second)])
    for first, second in edges:
        for color in range(colors):
            clauses.append([-var(first, color), -var(second, color)])
    return n * colors, clauses


def coloring_bruteforce(n, edges, colors, assignment):
    for vertex in range(n):
        chosen = [
            color for color in range(colors)
            if assignment[vertex * colors + color] == 1
        ]
        if len(chosen) != 1:
            return False
    for first, second in edges:
        if any(
            assignment[first * colors + color] == 1
            and assignment[second * colors + color] == 1
            for color in range(colors)
        ):
            return False
    return True


def main():
    print("Límite de variables para HAMPATH:")
    for n in [5, 10, 20, 50]:
        print("  n=%d: log2(n!) ≈ %.2f" % (n, math.lgamma(n + 1) / math.log(2)))

    print("\nSet Splitting:")
    elements = 5
    sets = [[1, 2, 3], [3, 4, 5], [1, 5]]
    n, clauses = set_splitting_cnf(elements, sets)
    mismatches = 0
    for bits in itertools.product((0, 1), repeat=n):
        if satisfies(n, clauses, bits) != set_splitting_bruteforce(
            elements, sets, bits
        ):
            mismatches += 1
    print(
        "  N=%d, M=%d, discrepancias=%d"
        % (n, len(clauses), mismatches)
    )

    print("\nColoración:")
    rng = random.Random(0)
    graph_n = 5
    edges = [
        (i, j)
        for i in range(graph_n)
        for j in range(i + 1, graph_n)
        if rng.random() < 0.4
    ]
    colors = 3
    n, clauses = coloring_cnf(graph_n, edges, colors)
    mismatches = 0
    for bits in itertools.product((0, 1), repeat=n):
        if satisfies(n, clauses, bits) != coloring_bruteforce(
            graph_n, edges, colors, bits
        ):
            mismatches += 1
    print(
        "  N=%d, M=%d, discrepancias=%d"
        % (n, len(clauses), mismatches)
    )


if __name__ == "__main__":
    main()
