"""
Ecuación SAT generalizada de Riveros.

Convención (la de la segunda parte del manuscrito y de la nota unificadora):
    0 = falso, 1 = verdadero.

Para una asignación a = (a_1, ..., a_N):
    pos(a) = sum_{i=1..N} a_i * 2^(N-i).

Una cláusula C es falsa exactamente cuando cada variable presente i cumple
a_i = 0 si +i está en C, y a_i = 1 si -i está en C.

Sean P_C las variables presentes, M_C las ausentes y
    B(C) = sum_{i in P_C} r_i * 2^(N-i),  r_i = 0 si +i, 1 si -i.
La máscara de C es
    S_C = 2^(B(C)) * prod_{i in M_C} (1 + 2^(2^(N-i))),
forma cerrada del OR
    S_C = OR_{M' subconjunto de M_C} 2^(B(C) + sum_{i in M'} 2^(N-i)).
El entero de la fórmula es S = OR_C S_C. El bit k de S vale 1 syss la
asignación de posición k falsifica la fórmula.
"""


def pos(assignment):
    """Posición entera de una asignación (a_1 es el bit más significativo)."""
    value = 0
    for bit_value in assignment:
        if bit_value not in (0, 1):
            raise ValueError("Cada bit de la asignación debe ser 0 o 1.")
        value = (value << 1) | bit_value
    return value


def assignment_at(position, n):
    """Asignación de N bits cuya posición es `position`."""
    if n < 0:
        raise ValueError("N debe ser no negativo.")
    if not 0 <= position < (1 << n):
        raise ValueError("La posición debe estar en [0, 2^N).")
    return tuple((position >> (n - i)) & 1 for i in range(1, n + 1))


def _required_bits(n, clause):
    """Devuelve {variable: bit_requerido}, o None si la cláusula es tautológica."""
    required = {}
    tautology = False
    for literal in clause:
        if not isinstance(literal, int) or literal == 0:
            raise ValueError("Literal inválido: %r." % (literal,))
        variable = abs(literal)
        if not 1 <= variable <= n:
            raise ValueError("La variable %d no está en 1..%d." % (variable, n))
        bit = 0 if literal > 0 else 1
        if variable in required and required[variable] != bit:
            tautology = True
        required[variable] = bit
    return None if tautology else required


def clause_mask(n, clause):
    """
    Máscara de 2^N bits de una cláusula.

    El bit k vale 1 syss la asignación de posición k falsifica la cláusula.
    Una tautología tiene máscara 0.
    """
    required = _required_bits(n, clause)
    if required is None:
        return 0

    base = 0
    for variable, bit in required.items():
        if bit:
            base += 1 << (n - variable)

    mask = 1 << base
    for variable in range(1, n + 1):
        if variable not in required:
            # Variable ausente: duplica la máscara 2^(N-i) posiciones arriba.
            mask *= 1 + (1 << (1 << (n - variable)))
    return mask


def sat_equation(n, clauses):
    """Entero S de la Ecuación SAT generalizada para una CNF sobre N variables."""
    if n < 0:
        raise ValueError("N debe ser no negativo.")
    S = 0
    for clause in clauses:
        S |= clause_mask(n, clause)
    return S


def bit_at(S, position):
    """Bit de S en la posición indicada."""
    if position < 0:
        raise ValueError("La posición debe ser no negativa.")
    return (S >> position) & 1


def popcount(S):
    """Número de bits en 1 de S."""
    return bin(S).count("1")


def clause_satisfied(clause, assignment):
    """Valor de verdad de una cláusula bajo una asignación."""
    for literal in clause:
        if literal == 0 or abs(literal) > len(assignment):
            raise ValueError("Literal fuera de rango.")
        value = assignment[abs(literal) - 1]
        if literal > 0:
            if value == 1:
                return True
        elif value == 0:
            return True
    return False


def formula_satisfied(n, clauses, assignment):
    """Valor de verdad de una CNF bajo una asignación."""
    if len(assignment) != n:
        raise ValueError("La asignación debe tener %d bits." % n)
    return all(clause_satisfied(clause, assignment) for clause in clauses)


def verify_equation(n, clauses, S=None):
    """Comprueba, asignación por asignación, que S codifica la tabla de verdad."""
    if S is None:
        S = sat_equation(n, clauses)

    clause_data = []
    for clause in clauses:
        required = _required_bits(n, clause)
        if required is None:
            continue
        present_mask = 0
        required_mask = 0
        for variable, bit in required.items():
            weight = 1 << (n - variable)
            present_mask |= weight
            if bit:
                required_mask |= weight
        clause_data.append((present_mask, required_mask))

    total = 1 << n
    bits = binary_string(S, n)
    for position in range(total):
        # La cláusula es falsa syss sus bits presentes coinciden con el patrón.
        falsified = False
        for present_mask, required_mask in clause_data:
            if (position & present_mask) == required_mask:
                falsified = True
                break
        if bits[total - 1 - position] != ("1" if falsified else "0"):
            return False
    return True


def is_satisfying(n, clauses, assignment, S=None):
    """True syss la asignación satisface la fórmula, consultando S."""
    if len(assignment) != n:
        raise ValueError("La asignación debe tener %d bits." % n)
    if S is None:
        S = sat_equation(n, clauses)
    return bit_at(S, pos(assignment)) == 0


def satisfying_assignments(n, clauses, S=None):
    """Genera las asignaciones satisfacientes en orden de posición."""
    if S is None:
        S = sat_equation(n, clauses)
    total = 1 << n
    bits = binary_string(S, n)
    for position in range(total):
        if bits[total - 1 - position] == "0":
            yield assignment_at(position, n)


def count_models(n, clauses, S=None):
    """Número de asignaciones satisfacientes."""
    if S is None:
        S = sat_equation(n, clauses)
    return (1 << n) - popcount(S)


def truth_table(n, clauses, S=None):
    """
    Cadena de 2^N caracteres en orden de posición:
    el carácter k es '1' si la asignación k falsifica la fórmula, '0' si la satisface.
    """
    if S is None:
        S = sat_equation(n, clauses)
    return binary_string(S, n)[::-1]


def binary_string(S, n):
    """
    Expansión binaria de S con 2^N dígitos, en el orden habitual (MSB primero).
    El último carácter corresponde al bit 0.
    """
    width = 1 << n
    return format(S, "0%db" % width)[-width:]


def parse_dimacs(text):
    """Lee una CNF en formato DIMACS y devuelve (N, cláusulas)."""
    n = None
    declared_clauses = None
    clauses = []
    current = []

    for raw_line in text.splitlines():
        line = raw_line.strip()
        if not line or line.startswith("c"):
            continue
        if line.startswith("%"):
            break
        if line.startswith("p"):
            parts = line.split()
            if len(parts) != 4 or parts[1] != "cnf":
                raise ValueError("Cabecera DIMACS inválida; se esperaba 'p cnf N M'.")
            if n is not None:
                raise ValueError("Hay más de una cabecera DIMACS.")
            n = int(parts[2])
            declared_clauses = int(parts[3])
            if n < 0 or declared_clauses < 0:
                raise ValueError("N y M deben ser no negativos.")
            continue
        if n is None:
            raise ValueError("Falta la cabecera 'p cnf N M' antes de las cláusulas.")
        for token in line.split():
            literal = int(token)
            if literal == 0:
                clauses.append(current)
                current = []
            else:
                current.append(literal)

    if n is None:
        raise ValueError("El archivo no contiene una cabecera 'p cnf N M'.")
    if current:
        raise ValueError("La última cláusula no termina en 0.")
    if declared_clauses is not None and len(clauses) != declared_clauses:
        raise ValueError(
            "La cabecera declara %d cláusulas, pero hay %d."
            % (declared_clauses, len(clauses))
        )
    for clause in clauses:
        _required_bits(n, clause)
    return n, clauses


def to_dimacs(n, clauses, comment=None):
    """Serializa una CNF a formato DIMACS."""
    if n < 0:
        raise ValueError("N debe ser no negativo.")
    clauses = list(clauses)
    lines = []
    if comment:
        for line in str(comment).splitlines():
            lines.append("c " + line if line else "c")
    lines.append("p cnf %d %d" % (n, len(clauses)))
    for clause in clauses:
        clause = list(clause)
        for literal in clause:
            if (
                not isinstance(literal, int)
                or literal == 0
                or not 1 <= abs(literal) <= n
            ):
                raise ValueError("Literal inválido para N=%d: %r." % (n, literal))
        lines.append(" ".join(str(lit) for lit in clause) + (" 0" if clause else "0"))
    return "\n".join(lines) + "\n"


def read_dimacs(path):
    """Lee un archivo DIMACS y devuelve (N, cláusulas)."""
    with open(path, "r", encoding="utf-8") as file:
        return parse_dimacs(file.read())


def write_dimacs(path, n, clauses, comment=None):
    """Escribe una CNF en formato DIMACS."""
    with open(path, "w", encoding="utf-8", newline="\n") as file:
        file.write(to_dimacs(n, clauses, comment=comment))


def _demo():
    examples = [
        (3, [(1, 2, -3), (-1, 2, 3)], 18),
        (3, [(1, -2)], 12),
        (3, [(1, -2), (-1, 2, 3)], 28),
    ]
    for n, clauses, expected in examples:
        S = sat_equation(n, clauses)
        assert S == expected, (S, expected)
        assert verify_equation(n, clauses)
        print("N=%d, S=%d, binario=%s" % (n, S, binary_string(S, n)))

    assert sat_equation(2, [[1, -1]]) == 0
    assert sat_equation(2, [[]]) == (1 << 4) - 1
    assert verify_equation(2, [[1, -1]])
    assert verify_equation(2, [[]])

    import random

    rng = random.Random(0)
    for n in range(1, 7):
        for _ in range(20):
            clauses = []
            for _ in range(rng.randint(0, 8)):
                width = rng.randint(1, n)
                variables = rng.sample(range(1, n + 1), width)
                clauses.append([v if rng.getrandbits(1) else -v for v in variables])
            assert verify_equation(n, clauses)

    print("Ecuación SAT generalizada: ejemplos y pruebas aleatorias OK.")


def main(argv=None):
    import argparse

    parser = argparse.ArgumentParser(
        description="Calcula y verifica la Ecuación SAT generalizada para una CNF DIMACS."
    )
    parser.add_argument("path", help="archivo CNF en formato DIMACS")
    parser.add_argument(
        "--check",
        action="store_true",
        help="verifica el teorema para todas las asignaciones",
    )
    parser.add_argument(
        "--models",
        action="store_true",
        help="enumera las asignaciones satisfacientes",
    )
    parser.add_argument(
        "--show-s",
        action="store_true",
        help="muestra S y su expansión binaria",
    )
    args = parser.parse_args(argv)

    n, clauses = read_dimacs(args.path)
    S = sat_equation(n, clauses)
    print(
        "N=%d, cláusulas=%d, posiciones=%d, modelos=%d, prohibidas=%d"
        % (n, len(clauses), 1 << n, count_models(n, clauses, S), popcount(S))
    )
    if args.show_s:
        print("S = %d" % S)
        if n <= 16:
            print("binario = %s" % binary_string(S, n))
        else:
            print("binario omitido: %d bits" % (1 << n))
    if args.check:
        if not verify_equation(n, clauses, S):
            raise SystemExit("ERROR: la expansión de S no coincide con la tabla de verdad.")
        print("Ecuación verificada para todas las asignaciones.")
    if args.models:
        for assignment in satisfying_assignments(n, clauses, S):
            print("".join(str(bit) for bit in assignment))


if __name__ == "__main__":
    import sys

    if len(sys.argv) == 1:
        _demo()
    else:
        main()
