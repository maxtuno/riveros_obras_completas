"""
Compresión de la Ecuación SAT por simetrías.

Idea:
    Si G es un grupo de permutaciones de variables que preserva la CNF F,
    entonces S(F) es constante en cada órbita de G sobre {0,1}^n.
    Por tanto, UNSAT (S(F) todo unos) se decide con un bit por órbita.

Babai/localización canónica es la pieza que encuentra G. En este prototipo
el grupo se obtiene por enumeración exacta para n <= 8 o con generadores
conocidos para las familias PHP y paridad. El objetivo es medir el efecto
SAT, no sustituir todavía a Babai.

No es un algoritmo para CNF arbitrarias: si G es trivial, el número de
órbitas es 2^n y no hay compresión.
"""

import math
import random
import time
from collections import Counter
from itertools import permutations

from sat_equation import (
    assignment_at,
    clause_satisfied,
    formula_satisfied,
    popcount,
    sat_equation,
)
from cnf_generator import pigeonhole_cnf, random_kcnf


# ----------------------------------------------------------------------
# 1. Permutaciones de variables y automorfismos de una CNF
# ----------------------------------------------------------------------

def canonical_clause(clause):
    """Representación de una cláusula independiente del orden de literales."""
    return tuple(sorted(clause, key=abs))


def clause_set(clauses):
    return frozenset(canonical_clause(clause) for clause in clauses)


def apply_perm_to_clause(clause, permutation):
    """Imagen de una cláusula bajo una permutación de variables (0-based)."""
    return [
        (1 if literal > 0 else -1) * (permutation[abs(literal) - 1] + 1)
        for literal in clause
    ]


def automorphisms_bruteforce(n, clauses):
    """Todos los automorfismos de la CNF. Sólo para n pequeño."""
    target = clause_set(clauses)
    automorphisms = []
    for permutation in permutations(range(n)):
        image = frozenset(
            canonical_clause(apply_perm_to_clause(clause, permutation))
            for clause in clauses
        )
        if image == target:
            automorphisms.append(permutation)
    return automorphisms


def perm_to_swaps(permutation):
    """
    Descompone una permutación en intercambios de variables.
    Aplicar los intercambios en orden mueve el bit i a permutation[i].
    """
    n = len(permutation)
    seen = [False] * n
    swaps = []
    for start in range(n):
        if seen[start]:
            continue
        cycle = []
        vertex = start
        while not seen[vertex]:
            seen[vertex] = True
            cycle.append(vertex)
            vertex = permutation[vertex]
        for index in range(len(cycle) - 1, 0, -1):
            swaps.append((cycle[index - 1], cycle[index]))
    return swaps


def swap_bits(position, n, first, second):
    """Intercambia los bits de las variables first y second en una posición."""
    first_bit = n - 1 - first
    second_bit = n - 1 - second
    value_first = (position >> first_bit) & 1
    value_second = (position >> second_bit) & 1
    if value_first == value_second:
        return position
    return position ^ ((1 << first_bit) | (1 << second_bit))


def apply_swaps(position, n, swaps):
    for first, second in swaps:
        position = swap_bits(position, n, first, second)
    return position


def php_generators(pigeons, holes):
    """Generadores de S_p x S_h para el principio del palomar."""
    generators = []
    for row in range(pigeons - 1):
        generators.append(
            [
                (row * holes + hole, (row + 1) * holes + hole)
                for hole in range(holes)
            ]
        )
    for column in range(holes - 1):
        generators.append(
            [
                (pigeon * holes + column, pigeon * holes + column + 1)
                for pigeon in range(pigeons)
            ]
        )
    return generators


def parity_generators(n):
    """Generadores de S_n: intercambios adyacentes de variables."""
    return [[(index, index + 1)] for index in range(n - 1)]


def php_group_elements(pigeons, holes):
    """Todos los elementos de S_p x S_h, para validar Burnside."""
    n = pigeons * holes
    for row_permutation in permutations(range(pigeons)):
        for column_permutation in permutations(range(holes)):
            permutation = [0] * n
            for pigeon in range(pigeons):
                for hole in range(holes):
                    permutation[pigeon * holes + hole] = (
                        row_permutation[pigeon] * holes
                        + column_permutation[hole]
                    )
            yield tuple(permutation)


def cycle_count(permutation):
    n = len(permutation)
    seen = [False] * n
    cycles = 0
    for start in range(n):
        if seen[start]:
            continue
        cycles += 1
        vertex = start
        while not seen[vertex]:
            seen[vertex] = True
            vertex = permutation[vertex]
    return cycles


def burnside_orbit_count(group_elements):
    """Número de órbitas por Burnside: (1/|G|) * suma 2^c(g)."""
    group_elements = list(group_elements)
    total = sum(1 << cycle_count(permutation) for permutation in group_elements)
    return total // len(group_elements)


# ----------------------------------------------------------------------
# 2. Órbitas de asignaciones
# ----------------------------------------------------------------------

def orbit_partition(n, generators):
    """
    Calcula las órbitas de {0,1}^n bajo los generadores dados.
    Devuelve (representantes, tamaños, órbita_de_cada_posición, tiempo).
    """
    started = time.perf_counter()
    total = 1 << n

    if not generators:
        representatives = list(range(total))
        sizes = [1] * total
        orbit_of = list(range(total))
        return representatives, sizes, orbit_of, time.perf_counter() - started

    parent = list(range(total))
    rank = [0] * total

    def find(node):
        while parent[node] != node:
            parent[node] = parent[parent[node]]
            node = parent[node]
        return node

    def union(first, second):
        root_first = find(first)
        root_second = find(second)
        if root_first == root_second:
            return
        if rank[root_first] < rank[root_second]:
            root_first, root_second = root_second, root_first
        parent[root_second] = root_first
        if rank[root_first] == rank[root_second]:
            rank[root_first] += 1

    for swaps in generators:
        for position in range(total):
            union(position, apply_swaps(position, n, swaps))

    root_to_id = {}
    representatives = []
    sizes = []
    for position in range(total):
        root = find(position)
        orbit_id = root_to_id.get(root)
        if orbit_id is None:
            orbit_id = len(representatives)
            root_to_id[root] = orbit_id
            representatives.append(position)
            sizes.append(0)
        sizes[orbit_id] += 1

    orbit_of = [0] * total
    for position in range(total):
        orbit_of[position] = root_to_id[find(position)]

    return representatives, sizes, orbit_of, time.perf_counter() - started


# ----------------------------------------------------------------------
# 3. Ecuación SAT cociente
# ----------------------------------------------------------------------

def quotient_bits(n, clauses, representatives):
    """Un bit de S(F) por representante de órbita."""
    started = time.perf_counter()
    bits = []
    for representative in representatives:
        assignment = assignment_at(representative, n)
        bits.append(0 if formula_satisfied(n, clauses, assignment) else 1)
    return bits, time.perf_counter() - started


def bits_to_int(bits):
    value = 0
    for index, bit in enumerate(bits):
        if bit:
            value |= 1 << index
    return value


def clause_to_pattern(clause, n):
    pattern = [None] * n
    for literal in clause:
        pattern[abs(literal) - 1] = 0 if literal > 0 else 1
    return tuple(pattern)


def swap_pattern(pattern, first, second):
    values = list(pattern)
    values[first], values[second] = values[second], values[first]
    return tuple(values)


def clause_orbits(n, clauses, generators):
    """Órbitas de cláusulas bajo el grupo; devuelve representantes y total."""
    patterns = {clause_to_pattern(clause, n) for clause in clauses}
    seen = set()
    representatives = []
    for pattern in patterns:
        if pattern in seen:
            continue
        representatives.append(pattern)
        stack = [pattern]
        seen.add(pattern)
        while stack:
            current = stack.pop()
            for swaps in generators:
                image = current
                for first, second in swaps:
                    image = swap_pattern(image, first, second)
                if image not in seen:
                    seen.add(image)
                    stack.append(image)
    return representatives, len(patterns)


def quotient_equation(n, clauses, representatives):
    """
    Construye S(F) en el cociente: un bit por órbita de asignaciones.

    Se evalúan todas las cláusulas. Una sola cláusula por órbita de cláusulas
    no basta: su cubo no es invariante bajo G. Lo invariante es la unión de
    la órbita completa de la cláusula. La compresión correcta es por órbitas
    de asignaciones.
    """
    quotient = 0
    for clause in clauses:
        mask = 0
        for orbit_id, representative in enumerate(representatives):
            assignment = assignment_at(representative, n)
            if not clause_satisfied(clause, assignment):
                mask |= 1 << orbit_id
        quotient |= mask
    return quotient


# ----------------------------------------------------------------------
# 4. Familias de prueba
# ----------------------------------------------------------------------

def parity_formula(n, parities):
    """CNF con una cláusula completa por asignación cuya paridad está en el conjunto."""
    clauses = []
    for position in range(1 << n):
        if (bin(position).count("1") & 1) not in parities:
            continue
        clause = []
        for variable in range(n):
            bit = (position >> (n - 1 - variable)) & 1
            clause.append(variable + 1 if bit == 0 else -(variable + 1))
        clauses.append(clause)
    return clauses


def copies_formula(base_clauses, copies):
    """Concatena copias disjuntas de una fórmula base sobre variables 1..ancho."""
    width = max(abs(literal) for clause in base_clauses for literal in clause)
    clauses = []
    for copy in range(copies):
        offset = copy * width
        for clause in base_clauses:
            clauses.append(
                [
                    (1 if literal > 0 else -1) * (abs(literal) + offset)
                    for literal in clause
                ]
            )
    return copies * width, clauses


# ----------------------------------------------------------------------
# 5. Análisis de una instancia
# ----------------------------------------------------------------------

def analyze(name, n, clauses, generators, group_size, group_time=0.0):
    representatives, sizes, orbit_of, orbit_time = orbit_partition(n, generators)
    bits, evaluation_time = quotient_bits(n, clauses, representatives)
    quotient = quotient_equation(n, clauses, representatives)
    if quotient != bits_to_int(bits):
        raise AssertionError("La ecuación SAT cociente no coincide con los bits.")
    clause_representatives, total_clauses = clause_orbits(n, clauses, generators)
    clause_orbit_count = len(clause_representatives)

    started = time.perf_counter()
    S = sat_equation(n, clauses)
    full_time = time.perf_counter() - started
    full_models = (1 << n) - popcount(S)
    models = sum(
        size for size, bit in zip(sizes, bits) if bit == 0
    )
    if models != full_models:
        raise AssertionError("El conteo cociente no coincide con el completo.")

    status = "UNSAT" if all(bits) else "SAT"
    witness = None
    if status == "SAT":
        for orbit_id, bit in enumerate(bits):
            if bit == 0:
                witness = assignment_at(representatives[orbit_id], n)
                break
        if not formula_satisfied(n, clauses, witness):
            raise AssertionError("El testigo no satisface la fórmula.")

    return {
        "name": name,
        "n": n,
        "m": len(clauses),
        "status": status,
        "group_size": group_size,
        "orbits": len(representatives),
        "full_bits": 1 << n,
        "ratio": (1 << n) / len(representatives),
        "clause_orbits": clause_orbit_count,
        "total_clauses": total_clauses,
        "full_models": full_models,
        "models": models,
        "witness": witness,
        "full_time": full_time,
        "orbit_time": orbit_time,
        "evaluation_time": evaluation_time,
        "group_time": group_time,
        "representatives": representatives,
        "sizes": sizes,
        "bits": bits,
        "orbit_of": orbit_of,
    }


def print_main_table(results):
    print("| instancia | n | m | estado | |G| | órbitas | bits | ratio | órbitas cl. | S completo (s) | cuota (s) | órbitas (s) |")
    print("|---|---:|---:|---|---:|---:|---:|---:|---:|---:|---:|---:|")
    for result in results:
        print(
            "| %s | %d | %d | %s | %d | %d | %d | %.1f | %d | %.4f | %.4f | %.3f |"
            % (
                result["name"],
                result["n"],
                result["m"],
                result["status"],
                result["group_size"],
                result["orbits"],
                result["full_bits"],
                result["ratio"],
                result["clause_orbits"],
                result["full_time"],
                result["evaluation_time"],
                result["orbit_time"],
            )
        )


def print_burnside_table(results):
    print("\n### Validación de Burnside")
    print("| instancia | |G| | Burnside | union-find |")
    print("|---|---:|---:|---:|")
    for result in results:
        if "burnside" not in result:
            continue
        print(
            "| %s | %d | %d | %d |"
            % (
                result["name"],
                result["group_size"],
                result["burnside"],
                result["orbits"],
            )
        )


# ----------------------------------------------------------------------
# 6. Partes del número: prefijos y muestras aleatorias
# ----------------------------------------------------------------------

def prefix_stats(result, k):
    orbit_of = result["orbit_of"]
    sizes = result["sizes"]
    hit = set(orbit_of[:k])
    coverage = sum(sizes[orbit_id] for orbit_id in hit)
    return len(hit), coverage


def random_stats(result, k, trials=5, seed=0):
    rng = random.Random(seed)
    total_positions = 1 << result["n"]
    orbit_of = result["orbit_of"]
    sizes = result["sizes"]
    hit_values = []
    coverage_values = []
    for _ in range(trials):
        sample = rng.sample(range(total_positions), k)
        hit = {orbit_of[position] for position in sample}
        hit_values.append(len(hit))
        coverage_values.append(sum(sizes[orbit_id] for orbit_id in hit))
    return (
        sum(hit_values) / trials,
        sum(coverage_values) / trials,
    )


def print_partial_table(result, prefix_sizes, random_sizes):
    total_positions = 1 << result["n"]
    total_orbits = result["orbits"]
    print("\n### %s: prefijos y muestras" % result["name"])
    print("| estrategia | bits leídos | órbitas alcanzadas | cobertura de asignaciones |")
    print("|---|---:|---:|---:|")
    for k in prefix_sizes:
        if k > total_positions:
            continue
        hit, coverage = prefix_stats(result, k)
        print(
            "| prefijo lexicográfico | %d | %d/%d (%.1f%%) | %.2f%% |"
            % (k, hit, total_orbits, 100.0 * hit / total_orbits, 100.0 * coverage / total_positions)
        )
    for k in random_sizes:
        if k > total_positions:
            continue
        hit, coverage = random_stats(result, k)
        print(
            "| muestra aleatoria | %d | %.1f/%d (%.1f%%) | %.2f%% |"
            % (k, hit, total_orbits, 100.0 * hit / total_orbits, 100.0 * coverage / total_positions)
        )
    print(
        "| una por órbita (óptimo) | %d | %d/%d (100%%) | 100.00%% |"
        % (total_orbits, total_orbits, total_orbits)
    )


# ----------------------------------------------------------------------
# 7. Isomorfismo de residuos (simetría dinámica)
# ----------------------------------------------------------------------

def canonical_under_vars(n, clauses):
    """Forma canónica de una CNF bajo permutaciones de sus n variables."""
    target = [tuple(clause) for clause in clauses]
    best = None
    for permutation in permutations(range(n)):
        image = tuple(
            sorted(
                canonical_clause(apply_perm_to_clause(clause, permutation))
                for clause in target
            )
        )
        if best is None or image < best:
            best = image
    return best


def residual(n, clauses, variable, value):
    """Residuo de fijar una variable; devuelve su forma canónica o UNSAT/EMPTY."""
    remaining = [index for index in range(n) if index != variable]
    index_of = {old: new for new, old in enumerate(remaining)}
    residual_clauses = []
    for clause in clauses:
        new_clause = []
        satisfied = False
        for literal in clause:
            current = abs(literal) - 1
            if current == variable:
                if (value == 1 and literal > 0) or (value == 0 and literal < 0):
                    satisfied = True
                    break
            else:
                new_clause.append(
                    (1 if literal > 0 else -1) * (index_of[current] + 1)
                )
        if satisfied:
            continue
        if not new_clause:
            return "UNSAT"
        residual_clauses.append(new_clause)
    if not residual_clauses:
        return "EMPTY"
    return canonical_under_vars(len(remaining), residual_clauses)


def depth1_classes(n, clauses):
    """Clases de isomorfismo de todos los residuos que fijan una variable."""
    forms = []
    for variable in range(n):
        forms.append(residual(n, clauses, variable, 0))
        forms.append(residual(n, clauses, variable, 1))
    counts = Counter(forms)
    unsat = sum(1 for form in counts if form == "UNSAT")
    return len(counts), unsat, sorted(counts.values(), reverse=True)


def sibling_isomorphic(n, clauses):
    """Pares de hermanos (misma variable, valores 0 y 1) isomorfos."""
    total = 0
    for variable in range(n):
        left = residual(n, clauses, variable, 0)
        right = residual(n, clauses, variable, 1)
        if left == right and left != "UNSAT":
            total += 1
    return total


def print_residual_table(instances):
    print("\n### Clases de isomorfismo de residuos a profundidad 1")
    print("| instancia | residuos | clases | UNSAT | hermanos isomorfos |")
    print("|---|---:|---:|---:|---:|")
    for name, n, clauses in instances:
        classes, unsat, _ = depth1_classes(n, clauses)
        siblings = sibling_isomorphic(n, clauses)
        print(
            "| %s | %d | %d | %d | %d |"
            % (name, 2 * n, classes, unsat, siblings)
        )


# ----------------------------------------------------------------------
# 8. Programa principal
# ----------------------------------------------------------------------

def build_results():
    results = []

    for pigeons, holes in [(3, 2), (4, 3), (5, 4)]:
        n, clauses = pigeonhole_cnf(pigeons, holes)
        generators = php_generators(pigeons, holes)
        group_size = math.factorial(pigeons) * math.factorial(holes)
        result = analyze(
            "PHP(%d,%d)" % (pigeons, holes),
            n,
            clauses,
            generators,
            group_size,
        )
        result["burnside"] = burnside_orbit_count(
            php_group_elements(pigeons, holes)
        )
        results.append(result)

    for n in [10, 12]:
        for label, parities in [("paridad-SAT", {1}), ("paridad-UNSAT", {0, 1})]:
            clauses = parity_formula(n, parities)
            results.append(
                analyze(
                    "%s(n=%d)" % (label, n),
                    n,
                    clauses,
                    parity_generators(n),
                    math.factorial(n),
                )
            )

    n = 8
    clauses = random_kcnf(n, 34, 3, seed=0)
    started = time.perf_counter()
    automorphisms = automorphisms_bruteforce(n, clauses)
    group_time = time.perf_counter() - started
    generators = [perm_to_swaps(permutation) for permutation in automorphisms]
    result = analyze(
        "3-SAT aleatoria(n=8)",
        n,
        clauses,
        generators,
        len(automorphisms),
        group_time,
    )
    result["burnside"] = burnside_orbit_count(automorphisms)
    results.append(result)

    base = [[1, 2], [-1, 2]]
    n, clauses = copies_formula(base, 4)
    started = time.perf_counter()
    automorphisms = automorphisms_bruteforce(n, clauses)
    group_time = time.perf_counter() - started
    generators = [perm_to_swaps(permutation) for permutation in automorphisms]
    result = analyze(
        "4-copias(n=8)",
        n,
        clauses,
        generators,
        len(automorphisms),
        group_time,
    )
    result["burnside"] = burnside_orbit_count(automorphisms)
    results.append(result)

    return results


def main():
    results = build_results()
    print_main_table(results)
    print_burnside_table(results)

    print("\n## Partes del número: no cualquier parte sirve")
    for name, prefix_sizes, random_sizes in [
        (
            "PHP(4,3)",
            [1, 64, 256, 1024, 4096],
            [87, 174, 348, 696],
        ),
        (
            "PHP(5,4)",
            [64, 1024, 4096, 16384, 65536],
            [1053, 2106, 4212, 8424],
        ),
    ]:
        result = next(item for item in results if item["name"] == name)
        print_partial_table(result, prefix_sizes, random_sizes)

    residual_instances = []
    for seed in range(3):
        residual_instances.append(
            ("3-SAT aleatoria(n=8,seed=%d)" % seed, 8, random_kcnf(8, 34, 3, seed))
        )
    n, clauses = pigeonhole_cnf(3, 2)
    residual_instances.append(("PHP(3,2)", n, clauses))
    n, clauses = copies_formula([[1, 2], [-1, 2]], 4)
    residual_instances.append(("4-copias(n=8)", n, clauses))
    print_residual_table(residual_instances)


if __name__ == "__main__":
    main()
