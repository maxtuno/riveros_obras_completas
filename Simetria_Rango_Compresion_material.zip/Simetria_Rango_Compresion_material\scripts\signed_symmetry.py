"""
Simetrías con signo de una CNF.

Un automorfismo firmado (π, ε) manda la variable i a π(i) y, si ε_i = 1,
niega su valor. Sobre asignaciones:

    y[π(i)] = x[i] XOR ε_i.

Se comparan las órbitas ordinarias (solo π) con las firmadas.
"""

import itertools

from sat_symmetry import canonical_clause, clause_set, parity_formula
from cnf_generator import pigeonhole_cnf, random_kcnf


def apply_signed(position, n, permutation, flips):
    result = 0
    for variable in range(n):
        bit = (position >> (n - 1 - variable)) & 1
        bit ^= flips[variable]
        image = permutation[variable]
        result |= bit << (n - 1 - image)
    return result


def signed_automorphisms_bruteforce(n, clauses):
    target = clause_set(clauses)
    automorphisms = []
    for permutation in itertools.permutations(range(n)):
        for flips in itertools.product((0, 1), repeat=n):
            image_set = set()
            for clause in clauses:
                image = []
                for literal in clause:
                    variable = abs(literal) - 1
                    sign = 1 if literal > 0 else -1
                    if flips[variable]:
                        sign = -sign
                    image.append(sign * (permutation[variable] + 1))
                image_set.add(canonical_clause(image))
            if frozenset(image_set) == target:
                automorphisms.append((permutation, flips))
    return automorphisms


def orbit_count_signed(n, automorphisms):
    total = 1 << n
    parent = list(range(total))

    def find(node):
        while parent[node] != node:
            parent[node] = parent[parent[node]]
            node = parent[node]
        return node

    def union(first, second):
        root_first = find(first)
        root_second = find(second)
        if root_first != root_second:
            parent[root_second] = root_first

    for permutation, flips in automorphisms:
        for position in range(total):
            union(position, apply_signed(position, n, permutation, flips))

    return len({find(position) for position in range(total)})


def main():
    n = 6
    cases = [
        ("F=(x1)", 2, [[1]]),
        ("F=(x1∨x2)∧(¬x1∨x2)=x2", 2, [[1, 2], [-1, 2]]),
        ("paridad impar n=5", 5, parity_formula(5, {1})),
        ("paridad impar n=6", 6, parity_formula(6, {1})),
        ("PHP(3,2)", 6, pigeonhole_cnf(3, 2)[1]),
        ("3-SAT aleatoria n=6", 6, random_kcnf(6, 25, 3, seed=0)),
    ]
    print("| instancia | n | aut. firmados | K ordinario | K firmado |")
    print("|---|---:|---:|---:|---:|")
    for name, n, clauses in cases:
        automorphisms = signed_automorphisms_bruteforce(n, clauses)
        unsigned = [
            (permutation, flips)
            for permutation, flips in automorphisms
            if all(bit == 0 for bit in flips)
        ]
        ordinary_k = orbit_count_signed(n, unsigned)
        signed_k = orbit_count_signed(n, automorphisms)
        print(
            "| %s | %d | %d | %d | %d |"
            % (name, n, len(automorphisms), ordinary_k, signed_k)
        )


if __name__ == "__main__":
    main()
