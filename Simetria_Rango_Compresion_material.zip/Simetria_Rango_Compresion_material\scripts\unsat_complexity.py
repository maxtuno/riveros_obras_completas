"""
Complejidad de decidir UNSAT con la Ecuación SAT cociente.

Pregunta:
    Dada una CNF F, ¿cuánto cuesta certificar que es UNSAT usando
    simetrías, en comparación con construir los 2^n bits de S(F)?

Respuesta corta:
    - En el peor caso (G trivial), no hay mejora: K = 2^n.
    - Para una familia con K = |Omega/G| manejable, el coste es
      O(K*m + T_G + T_orbits), frente a O(2^n*m).
    - El espacio del cociente es K bits, frente a 2^n bits.
    - UNSAT es la dirección universal: hay que comprobar las K órbitas.
      SAT es existencial: un solo cero da un testigo.

Este módulo mide esa diferencia en familias concretas. No modifica los
módulos anteriores.
"""

import math
import time
from itertools import combinations

from sat_equation import assignment_at, formula_satisfied, popcount, sat_equation
from cnf_generator import pigeonhole_cnf, random_kcnf
import sat_symmetry as sym


# ----------------------------------------------------------------------
# 1. Familias UNSAT con simetría controlada
# ----------------------------------------------------------------------

def cardinality_unsat(n, k):
    """
    CNF UNSAT: "a lo sumo k variables verdaderas" y "al menos k+1".

    Es invariante bajo S_n. Para k fijo, tiene O(n^(k+1)) cláusulas y
    n+1 órbitas de asignaciones (clasificadas por peso de Hamming).
    """
    if not 0 <= k < n:
        raise ValueError("Se requiere 0 <= k < n.")
    clauses = []
    for subset in combinations(range(1, n + 1), k + 1):
        clauses.append([-variable for variable in subset])
    for subset in combinations(range(1, n + 1), n - k):
        clauses.append(list(subset))
    return clauses


def unit_contradiction(n):
    """CNF UNSAT trivial: x_i y -x_i para cada variable. Invariante bajo S_n."""
    return [[variable] for variable in range(1, n + 1)] + [
        [-variable] for variable in range(1, n + 1)
    ]


def weight_orbits(n):
    """
    Órbitas de {0,1}^n bajo S_n: una por peso de Hamming.
    No enumera 2^n asignaciones.
    """
    representatives = [(1 << weight) - 1 for weight in range(n + 1)]
    sizes = [math.comb(n, weight) for weight in range(n + 1)]
    return representatives, sizes


# ----------------------------------------------------------------------
# 2. Medición de una instancia UNSAT
# ----------------------------------------------------------------------

def analyze_unsat(name, n, clauses, representatives, sizes,
                  group_size, orbit_time=0.0, group_time=0.0):
    """Calcula el cociente UNSAT y lo compara con la Ecuación SAT completa."""
    if sum(sizes) != (1 << n):
        raise AssertionError("Las órbitas no particionan Omega.")

    started = time.perf_counter()
    bits = []
    for representative in representatives:
        assignment = assignment_at(representative, n)
        bits.append(0 if formula_satisfied(n, clauses, assignment) else 1)
    quotient_time = time.perf_counter() - started

    if not all(bits):
        raise AssertionError("La instancia no es UNSAT o el cociente falló.")

    started = time.perf_counter()
    S = sat_equation(n, clauses)
    full_time = time.perf_counter() - started
    full_models = (1 << n) - popcount(S)
    if full_models != 0:
        raise AssertionError("La Ecuación SAT completa no es todo unos.")

    full_bits = 1 << n
    k = len(representatives)
    m = len(clauses)
    full_evaluations = full_bits * m
    quotient_evaluations = k * m

    return {
        "name": name,
        "n": n,
        "m": m,
        "group_size": group_size,
        "orbits": k,
        "full_bits": full_bits,
        "ratio": full_bits / k,
        "full_evaluations": full_evaluations,
        "quotient_evaluations": quotient_evaluations,
        "evaluation_ratio": full_evaluations / quotient_evaluations,
        "full_time": full_time,
        "quotient_time": quotient_time,
        "orbit_time": orbit_time,
        "group_time": group_time,
        "preprocess_time": group_time + orbit_time,
        "certificate_bits": k,
    }


def print_table(results):
    print("| instancia | n | m | K | bits completos | ratio | eval. completas | eval. cociente | S completo (s) | UNSAT cociente (s) | grupo+órbitas (s) |")
    print("|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|")
    for result in results:
        print(
            "| %s | %d | %d | %d | %d | %.1f | %d | %d | %.4f | %.4f | %.3f |"
            % (
                result["name"],
                result["n"],
                result["m"],
                result["orbits"],
                result["full_bits"],
                result["ratio"],
                result["full_evaluations"],
                result["quotient_evaluations"],
                result["full_time"],
                result["quotient_time"],
                result["preprocess_time"],
            )
        )


def print_scaling_table(results):
    print("\n### Escalado de la familia de cardinalidad (k=1)")
    print("| n | m | K | bits completos | ratio | eval. completas | eval. cociente | S completo (s) | UNSAT cociente (s) |")
    print("|---:|---:|---:|---:|---:|---:|---:|---:|---:|")
    for result in results:
        print(
            "| %d | %d | %d | %d | %.1f | %d | %d | %.4f | %.4f |"
            % (
                result["n"],
                result["m"],
                result["orbits"],
                result["full_bits"],
                result["ratio"],
                result["full_evaluations"],
                result["quotient_evaluations"],
                result["full_time"],
                result["quotient_time"],
            )
        )


# ----------------------------------------------------------------------
# 3. Construcción de las instancias
# ----------------------------------------------------------------------

def build_results():
    results = []

    # Cardinalidad: familia compacta con K = n+1.
    for n in [8, 12, 16, 20]:
        clauses = cardinality_unsat(n, 1)
        representatives, sizes = weight_orbits(n)
        results.append(
            analyze_unsat(
                "cardinalidad(n=%d,k=1)" % n,
                n,
                clauses,
                representatives,
                sizes,
                math.factorial(n),
            )
        )

    # Contradicción unitaria: K = n+1, m = 2n.
    n = 20
    clauses = unit_contradiction(n)
    representatives, sizes = weight_orbits(n)
    results.append(
        analyze_unsat(
            "unidades(n=20)",
            n,
            clauses,
            representatives,
            sizes,
            math.factorial(n),
        )
    )

    # PHP: K se obtiene por union-find en el prototipo.
    for pigeons, holes in [(3, 2), (4, 3), (5, 4)]:
        n, clauses = pigeonhole_cnf(pigeons, holes)
        generators = sym.php_generators(pigeons, holes)
        started = time.perf_counter()
        representatives, sizes, _, orbit_time = sym.orbit_partition(n, generators)
        results.append(
            analyze_unsat(
                "PHP(%d,%d)" % (pigeons, holes),
                n,
                clauses,
                representatives,
                sizes,
                math.factorial(pigeons) * math.factorial(holes),
                orbit_time,
            )
        )

    # Paridad UNSAT: K = n+1, pero m = 2^n.
    for n in [10, 12]:
        clauses = sym.parity_formula(n, {0, 1})
        representatives, sizes = weight_orbits(n)
        results.append(
            analyze_unsat(
                "paridad-UNSAT(n=%d)" % n,
                n,
                clauses,
                representatives,
                sizes,
                math.factorial(n),
            )
        )

    # 3-SAT aleatoria UNSAT: grupo trivial, K = 2^n.
    n = 8
    clauses = random_kcnf(n, 34, 3, seed=0)
    started = time.perf_counter()
    automorphisms = sym.automorphisms_bruteforce(n, clauses)
    group_time = time.perf_counter() - started
    generators = [sym.perm_to_swaps(permutation) for permutation in automorphisms]
    representatives, sizes, _, orbit_time = sym.orbit_partition(n, generators)
    results.append(
        analyze_unsat(
            "3-SAT aleatoria(n=8)",
            n,
            clauses,
            representatives,
            sizes,
            len(automorphisms),
            orbit_time,
            group_time,
        )
    )

    return results


def print_bounds():
    print("\n## Cotas de complejidad")
    print()
    print("Ecuación SAT completa:")
    print("  tiempo  O(2^n * m)")
    print("  espacio O(2^n) bits")
    print()
    print("Ecuación SAT cociente:")
    print("  tiempo  O(K * m + T_G + T_orbits)")
    print("  espacio O(K + S_G + S_orbits) bits")
    print("  K = número de órbitas de Omega bajo G = Aut(F)")
    print()
    print("Si K = poly(n,m) y T_G, T_orbits son polinómicos, UNSAT es")
    print("polinómico para esa familia. Si G es trivial, K = 2^n y no hay")
    print("mejora asintótica. El peor caso sigue siendo exponencial.")


def main():
    results = build_results()
    print_table(results)

    scaling = [
        result for result in results
        if result["name"].startswith("cardinalidad")
    ]
    print_scaling_table(scaling)
    print_bounds()


if __name__ == "__main__":
    main()
